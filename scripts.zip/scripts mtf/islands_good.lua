loadstring(game:HttpGet("http://void-scripts.com/Scripts/islands_new.lua"))()
