loadstring(game:HttpGet'https://raw.githubusercontent.com/Macintosh1983/fuckyouanomicmods/main/MAINSCRIPT')()
