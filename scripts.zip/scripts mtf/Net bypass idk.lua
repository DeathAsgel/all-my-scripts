--[[
for i,v in pairs(game:GetService("Players").LocalPlayer.Character:GetChildren()) do
if v:IsA("Accessory") then
print(Net Bypass Worked. Please do not remove credits Ynex#8292)
end
end
--]]
game.Players[LocalPlayer]:Kick("Net Bypass Installing...")