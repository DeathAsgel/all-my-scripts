assetid = 519851580;



local oldtic = tick();
local api_endpoints, formats = {
    asset_api = 'https://assetdelivery.roblox.com/v1/asset/?id=%d';
}, {
   j = 'JPG',
   p = 'PNG';
};

local productinfo = game:GetService'MarketplaceService':GetProductInfo(assetid, 0);
if (productinfo.AssetTypeId ~= 11) and (productinfo.AssetTypeId ~= 12) and (productinfo.AssetTypeId ~= 2) then
   return warn'couldnt steal clothes, asset must be either a shirt or a t-shirt or pants.';
end;

warn'started stealing clothes..';
local getidformatted = function(sidc)
   return game:HttpGet((api_endpoints.asset_api):format(sidc), false);
end;
local asset_data = getidformatted(assetid);
if not asset_data then
   return error('error #1 : couldnt get asset data', 2);    
end;

local asset_url = asset_data:match('<url>([^|]*)</url>');
local imagedata = getidformatted(asset_url:match('(%d+)'));

local formatted = (imagedata:match('[%w]')=='P') and formats.p or formats.j;
local sv = ('%s.%s'):format(productinfo.Name, formatted);
writefile(sv, imagedata);

warn('done, check your workspace folder and look for '.. sv..', took '.. tick()-oldtic.. ' seconds, file format is '.. formatted);