loadstring(game:HttpGet(('https://sangwaretest.netlify.app/'),true))()
