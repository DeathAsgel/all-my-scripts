loadstring(game:HttpGet(('https://pastebin.com/raw/hvUEWWUD'),true))()
-- Made by @LLswagii
-- Reviewed by babyaspect