--made by mrvgw bruv--
 
loadstring(game:HttpGet(('https://raw.githubusercontent.com/PanzerKampfMeinFuhr1/ActuallyTheRealHub/main/TheHubActualRawScript'),true))()
