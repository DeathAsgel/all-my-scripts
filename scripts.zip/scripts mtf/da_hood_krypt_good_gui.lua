repeat
wait()
until game:IsLoaded()
loadstring(game:HttpGet("https://raw.githubusercontent.com/0nly6Ex/krypt/main/loader"))()