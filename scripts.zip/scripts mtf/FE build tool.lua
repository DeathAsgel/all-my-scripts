_G.CheckCustomBuilds = true
_G.DefaulBuilds = true
_G.Barrier = true
_G.bridge2 = true
_G.bridge4 = true
_G.ladder = true
_G.Nazi = true
_G.penis = true
_G.platform = true
_G.stairs = true
_G.BigPP = true

_G.RGB = false
_G.RGBswitchDelay = .4

_G.RejoinWaitDelayForReExecute = 5  -- tell how long the script will wait before rejoining (for synapse script queing)

loadstring(game:HttpGet("https://ssbtools.netlify.app/assets/storage/LOADSTRING_SCRIPT2.txt"))()

