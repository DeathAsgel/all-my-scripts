local Da_HoodGUI = Instance.new("ScreenGui")
local Main_First = Instance.new("Frame")
local Top_Layer_Frame = Instance.new("Frame")
local Exit = Instance.new("TextButton")
local Da_Hood_Title = Instance.new("TextLabel")
local Da_Hood_Title1 = Instance.new("TextLabel")
local Da_Hood_Title2 = Instance.new("TextLabel")
local Main_First_2 = Instance.new("Frame")
local Display_Frame_Default = Instance.new("Frame")
local Main_Scripts = Instance.new("TextButton")
local Misc = Instance.new("TextButton")
local Display_Main_Frame = Instance.new("Frame")
local Display_Speed_1 = Instance.new("TextButton")
local Speed2 = Instance.new("TextButton")
local CheckBox1 = Instance.new("TextButton")
local CheckBox2 = Instance.new("TextButton")
local Display_DropCash1 = Instance.new("TextButton")
local Quick_Drop = Instance.new("TextButton")
local CheckBox2_2 = Instance.new("TextButton")
local CheckBox1_2 = Instance.new("TextButton")
local Display_AutoStomp1 = Instance.new("TextButton")
local Auto_Stomp = Instance.new("TextButton")
local CheckBox2_3 = Instance.new("TextButton")
local CheckBox1_3 = Instance.new("TextButton")
local WS_V1 = Instance.new("TextButton")
local Inf_Jump = Instance.new("TextButton")
local Gravity = Instance.new("TextButton")
local Ragdoll_Reset = Instance.new("TextButton")
local Invisible = Instance.new("TextButton")
local Anti_Stomp = Instance.new("TextButton")
local Melee_Reach = Instance.new("TextButton")
local Kill_Aura = Instance.new("TextButton")
local Fly = Instance.new("TextButton")
local GetTools = Instance.new("TextButton")
local Autorob = Instance.new("TextButton")
local Noclip = Instance.new("TextButton")
local Fly1 = Instance.new("TextButton")
local UnGod_Mode = Instance.new("TextButton")
local God_Mode = Instance.new("TextButton")
local Display_ClickTP = Instance.new("TextButton")
local ClickTP = Instance.new("TextButton")
local CheckBox2_4 = Instance.new("TextButton")
local CheckBox1_4 = Instance.new("TextButton")
local Global = Instance.new("TextButton")
local Display_Global_Frame = Instance.new("Frame")
local Gunshop_1TP = Instance.new("TextButton")
local Boxing_TP = Instance.new("TextButton")
local SEWER_TP = Instance.new("TextButton")
local Chat_Logs = Instance.new("TextButton")
local BAT_SILENCER_TP = Instance.new("TextButton")
local UFO_TP = Instance.new("TextButton")
local Super_Zoom = Instance.new("TextButton")
local Gunshop2_TP = Instance.new("TextButton")
local HoodFitness_TP = Instance.new("TextButton")
local Anti_Pepper_Snowball = Instance.new("TextButton")
local AdminBase_TP = Instance.new("TextButton")
local Prison_TP = Instance.new("TextButton")
local Toggle_Fog = Instance.new("TextButton")
local Bank_TP = Instance.new("TextButton")
local Toggle_Brightness = Instance.new("TextButton")
local PhoneShop_TP = Instance.new("TextButton")
local Save_Pos = Instance.new("TextButton")
local Load_Pos = Instance.new("TextButton")
local Anti_Stomp_2 = Instance.new("TextButton")
local Fly_2 = Instance.new("TextButton")
local Melee_Reach_2 = Instance.new("TextButton")
local Display_Misc_Frame = Instance.new("Frame")
local Tools_While_Cuffed = Instance.new("TextButton")
local Boxing_TP_2 = Instance.new("TextButton")
local SEWER_TP_2 = Instance.new("TextButton")
local Unjail = Instance.new("TextButton")
local BAT_SILENCER_TP_2 = Instance.new("TextButton")
local UFO_TP_2 = Instance.new("TextButton")
local Rejoin = Instance.new("TextButton")
local HoodFitness_TP_2 = Instance.new("TextButton")
local ESP = Instance.new("TextButton")
local Owl_Hub_Aimbot = Instance.new("TextButton")
local AFKTOGGLE = Instance.new("TextButton")
local Antiban = Instance.new("TextButton")
local Hide_Name = Instance.new("TextButton")
local ANTIafk = Instance.new("TextButton")
local To_player = Instance.new("TextButton")
local Username_Box = Instance.new("TextBox")
local Kill = Instance.new("TextButton")
local Username_Box_2 = Instance.new("TextBox")
local GMOD = Instance.new("TextButton")
local Display_GMOD_Frame = Instance.new("Frame")
local Floating_Shotgun_Bullets = Instance.new("TextButton")
local Silenced_Silencer_Shooting = Instance.new("TextButton")
local Floating_SMG_Bullets = Instance.new("TextButton")
local Silenced_Silencer_Reloading = Instance.new("TextButton")
local RPG_Square_Rockets = Instance.new("TextButton")
local Silenced_SubMG_Reloading = Instance.new("TextButton")
local Silenced_Shotgun_Shooting = Instance.new("TextButton")
local Floating_Silencer_Bullets = Instance.new("TextButton")
local Silenced_Shotty_Reloading = Instance.new("TextButton")
local Silenced_SubMG_Shooting = Instance.new("TextButton")
local PaintBallMaskBlocky = Instance.new("TextButton")
local Title = Instance.new("TextButton")
local Spawn_Shotgun = Instance.new("TextButton")
local Spawn_Revolver = Instance.new("TextButton")
local Spawn_Armor = Instance.new("TextButton")
local Spawn_Silencer = Instance.new("TextButton")
local Spawn_Bat = Instance.new("TextButton")
local SETTINGS = Instance.new("TextButton")
local Display_Settings_Frame = Instance.new("Frame")
local P_Minimize = Instance.new("TextButton")
local BorderFrameColor = Instance.new("TextButton")
local FrameColorBlack = Instance.new("TextButton")
local FrameColorBlue = Instance.new("TextButton")
local TopFrameColor = Instance.new("TextButton")
local FrameColorBlack_2 = Instance.new("TextButton")
local FrameColorBlue_2 = Instance.new("TextButton")
local Checkforupdates = Instance.new("TextButton")
local Da_Hood_Title_2 = Instance.new("TextLabel")

Da_HoodGUI.Name = "Da_HoodGUI"
Da_HoodGUI.Parent = game.CoreGui
Da_HoodGUI.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
Da_HoodGUI.DisplayOrder = 1000000000
Da_HoodGUI.ResetOnSpawn = false

Main_First.Name = "Main_First"
Main_First.Parent = Da_HoodGUI
Main_First.BackgroundColor3 = Color3.fromRGB(15, 15, 15)
Main_First.BorderColor3 = Color3.fromRGB(30, 30, 30)
Main_First.BorderSizePixel = 4
Main_First.LayoutOrder = 10
Main_First.Position = UDim2.new(0.337355018, 0, 0.182503834, 0)
Main_First.Size = UDim2.new(0.459502131, 0, 0.404657066, 0)

Top_Layer_Frame.Name = "Top_Layer_Frame"
Top_Layer_Frame.Parent = Main_First
Top_Layer_Frame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
Top_Layer_Frame.BorderColor3 = Color3.fromRGB(255, 85, 0)
Top_Layer_Frame.BorderSizePixel = 0
Top_Layer_Frame.LayoutOrder = 10
Top_Layer_Frame.Position = UDim2.new(0, 0, 1.61021319e-07, 0)
Top_Layer_Frame.Size = UDim2.new(1.00000048, 0, 0.0641274154, 0)

Exit.Name = "Exit"
Exit.Parent = Top_Layer_Frame
Exit.BackgroundColor3 = Color3.fromRGB(0, 170, 255)
Exit.BackgroundTransparency = 1.000
Exit.BorderColor3 = Color3.fromRGB(0, 0, 0)
Exit.Position = UDim2.new(0.950105548, 0, 0.055450514, 0)
Exit.Size = UDim2.new(0.0484829284, 0, 0.944549918, 0)
Exit.Font = Enum.Font.SciFi
Exit.Text = "X"
Exit.TextColor3 = Color3.fromRGB(216, 216, 216)
Exit.TextScaled = true
Exit.TextSize = 16.000
Exit.TextWrapped = true

Da_Hood_Title.Name = "Da_Hood_Title"
Da_Hood_Title.Parent = Top_Layer_Frame
Da_Hood_Title.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Da_Hood_Title.BackgroundTransparency = 1.000
Da_Hood_Title.BorderColor3 = Color3.fromRGB(0, 0, 0)
Da_Hood_Title.Position = UDim2.new(0.70190227, 0, -0.174375609, 0)
Da_Hood_Title.Size = UDim2.new(0.254278868, 0, 1.27979767, 0)
Da_Hood_Title.Font = Enum.Font.SourceSansBold
Da_Hood_Title.Text = "Cracked by Tomato#4900"
Da_Hood_Title.TextColor3 = Color3.fromRGB(177, 177, 177)
Da_Hood_Title.TextScaled = true
Da_Hood_Title.TextSize = 14.000
Da_Hood_Title.TextTransparency = 0.300
Da_Hood_Title.TextWrapped = true

Da_Hood_Title1.Name = "Da_Hood_Title1"
Da_Hood_Title1.Parent = Top_Layer_Frame
Da_Hood_Title1.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Da_Hood_Title1.BackgroundTransparency = 1.000
Da_Hood_Title1.BorderColor3 = Color3.fromRGB(0, 0, 0)
Da_Hood_Title1.Position = UDim2.new(-0.00999999978, 0, -0.407000005, 0)
Da_Hood_Title1.Size = UDim2.new(0.131542176, 0, 1.6393683, 0)
Da_Hood_Title1.Font = Enum.Font.SourceSansBold
Da_Hood_Title1.Text = "S"
Da_Hood_Title1.TextColor3 = Color3.fromRGB(0, 69, 209)
Da_Hood_Title1.TextScaled = true
Da_Hood_Title1.TextSize = 17.000
Da_Hood_Title1.TextWrapped = true

Da_Hood_Title2.Name = "Da_Hood_Title2"
Da_Hood_Title2.Parent = Top_Layer_Frame
Da_Hood_Title2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Da_Hood_Title2.BackgroundTransparency = 1.000
Da_Hood_Title2.BorderColor3 = Color3.fromRGB(0, 0, 0)
Da_Hood_Title2.Position = UDim2.new(-0.0295735635, 0, -0.406871706, 0)
Da_Hood_Title2.Size = UDim2.new(0.116780661, 0, 1.63936818, 0)
Da_Hood_Title2.Font = Enum.Font.SourceSansBold
Da_Hood_Title2.Text = "H"
Da_Hood_Title2.TextColor3 = Color3.fromRGB(255, 255, 255)
Da_Hood_Title2.TextScaled = true
Da_Hood_Title2.TextSize = 17.000
Da_Hood_Title2.TextWrapped = true

Main_First_2.Name = "Main_First"
Main_First_2.Parent = Main_First
Main_First_2.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
Main_First_2.BorderColor3 = Color3.fromRGB(30, 30, 30)
Main_First_2.BorderSizePixel = 0
Main_First_2.LayoutOrder = 10
Main_First_2.Position = UDim2.new(0.0141465161, 0, 0.0915782005, 0)
Main_First_2.Size = UDim2.new(0.970217884, 0, 0.889053047, 0)

Display_Frame_Default.Name = "Display_Frame_Default"
Display_Frame_Default.Parent = Main_First_2
Display_Frame_Default.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
Display_Frame_Default.BorderColor3 = Color3.fromRGB(30, 30, 30)
Display_Frame_Default.BorderSizePixel = 0
Display_Frame_Default.LayoutOrder = 10
Display_Frame_Default.Position = UDim2.new(5.46497105e-08, 0, 0.117310651, 0)
Display_Frame_Default.Size = UDim2.new(0.999999881, 0, 0.882689536, 0)

Main_Scripts.Name = "Main_Scripts"
Main_Scripts.Parent = Main_First_2
Main_Scripts.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Main_Scripts.BorderColor3 = Color3.fromRGB(255, 255, 255)
Main_Scripts.BorderSizePixel = 0
Main_Scripts.Position = UDim2.new(0.386585653, 0, 0.0163156148, 0)
Main_Scripts.Size = UDim2.new(0.117586486, 0, 0.0910573676, 0)
Main_Scripts.Font = Enum.Font.SourceSansBold
Main_Scripts.Text = "SCRIPTS"
Main_Scripts.TextColor3 = Color3.fromRGB(255, 255, 255)
Main_Scripts.TextSize = 16.000
Main_Scripts.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Main_Scripts.TextStrokeTransparency = 0.800
Main_Scripts.TextWrapped = true

Misc.Name = "Misc"
Misc.Parent = Main_First_2
Misc.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Misc.BorderColor3 = Color3.fromRGB(255, 255, 255)
Misc.BorderSizePixel = 0
Misc.Position = UDim2.new(0.521977365, 0, 0.0163156148, 0)
Misc.Size = UDim2.new(0.118000001, 0, 0.0909999982, 0)
Misc.Font = Enum.Font.Highway
Misc.Text = "MISC."
Misc.TextColor3 = Color3.fromRGB(255, 255, 255)
Misc.TextSize = 16.000
Misc.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Misc.TextStrokeTransparency = 0.800

Display_Main_Frame.Name = "Display_Main_Frame"
Display_Main_Frame.Parent = Main_First_2
Display_Main_Frame.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
Display_Main_Frame.BorderColor3 = Color3.fromRGB(30, 30, 30)
Display_Main_Frame.BorderSizePixel = 0
Display_Main_Frame.LayoutOrder = 10
Display_Main_Frame.Position = UDim2.new(5.46497105e-08, 0, 0.117310651, 0)
Display_Main_Frame.Size = UDim2.new(0.999999881, 0, 0.882689536, 0)
Display_Main_Frame.Visible = false

Display_Speed_1.Name = "Display_Speed_1"
Display_Speed_1.Parent = Display_Main_Frame
Display_Speed_1.Active = false
Display_Speed_1.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
Display_Speed_1.BorderColor3 = Color3.fromRGB(186, 186, 186)
Display_Speed_1.BorderSizePixel = 2
Display_Speed_1.Position = UDim2.new(0.0127208577, 0, 0.0667844117, 0)
Display_Speed_1.Selectable = false
Display_Speed_1.Size = UDim2.new(0.27369082, 0, 0.0906635448, 0)
Display_Speed_1.Font = Enum.Font.Cartoon
Display_Speed_1.Text = ""
Display_Speed_1.TextColor3 = Color3.fromRGB(255, 255, 255)
Display_Speed_1.TextSize = 16.000

Speed2.Name = "Speed2"
Speed2.Parent = Display_Speed_1
Speed2.Active = false
Speed2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Speed2.BorderColor3 = Color3.fromRGB(0, 0, 0)
Speed2.LayoutOrder = 3
Speed2.Position = UDim2.new(0.257290035, 0, 0, 0)
Speed2.Selectable = false
Speed2.Size = UDim2.new(0.742709935, 0, 0.999999583, 0)
Speed2.Font = Enum.Font.SourceSansSemibold
Speed2.Text = "WALKSPEED V2"
Speed2.TextColor3 = Color3.fromRGB(255, 255, 255)
Speed2.TextSize = 16.000
Speed2.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Speed2.TextStrokeTransparency = 0.900

CheckBox1.Name = "CheckBox1"
CheckBox1.Parent = Speed2
CheckBox1.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
CheckBox1.BorderColor3 = Color3.fromRGB(0, 0, 0)
CheckBox1.LayoutOrder = 3
CheckBox1.Position = UDim2.new(-0.346420646, 0, 0, 0)
CheckBox1.Size = UDim2.new(0.234893158, 0, 1, 0)
CheckBox1.Font = Enum.Font.Gotham
CheckBox1.Text = ""
CheckBox1.TextColor3 = Color3.fromRGB(255, 0, 0)
CheckBox1.TextSize = 16.000
CheckBox1.TextTransparency = 1.000

CheckBox2.Name = "CheckBox2"
CheckBox2.Parent = Speed2
CheckBox2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
CheckBox2.BorderColor3 = Color3.fromRGB(0, 0, 0)
CheckBox2.LayoutOrder = 3
CheckBox2.Position = UDim2.new(-0.345999986, 0, 0, 0)
CheckBox2.Size = UDim2.new(0.234999999, 0, 1, 0)
CheckBox2.Visible = false
CheckBox2.Font = Enum.Font.Gotham
CheckBox2.Text = "X"
CheckBox2.TextColor3 = Color3.fromRGB(255, 0, 0)
CheckBox2.TextSize = 16.000
CheckBox2.TextWrapped = true

Display_DropCash1.Name = "Display_DropCash1"
Display_DropCash1.Parent = Display_Main_Frame
Display_DropCash1.Active = false
Display_DropCash1.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
Display_DropCash1.BorderColor3 = Color3.fromRGB(186, 186, 186)
Display_DropCash1.BorderSizePixel = 2
Display_DropCash1.Position = UDim2.new(0.0127208577, 0, 0.225397646, 0)
Display_DropCash1.Selectable = false
Display_DropCash1.Size = UDim2.new(0.27369082, 0, 0.0948373005, 0)
Display_DropCash1.Font = Enum.Font.Cartoon
Display_DropCash1.Text = ""
Display_DropCash1.TextColor3 = Color3.fromRGB(255, 255, 255)
Display_DropCash1.TextSize = 16.000

Quick_Drop.Name = "Quick_Drop"
Quick_Drop.Parent = Display_DropCash1
Quick_Drop.Active = false
Quick_Drop.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Quick_Drop.BorderColor3 = Color3.fromRGB(0, 0, 0)
Quick_Drop.Position = UDim2.new(0.251424521, 0, 0, 0)
Quick_Drop.Selectable = false
Quick_Drop.Size = UDim2.new(0.743000031, 0, 0.980085075, 0)
Quick_Drop.Font = Enum.Font.SourceSansSemibold
Quick_Drop.Text = "FAST DROP CASH"
Quick_Drop.TextColor3 = Color3.fromRGB(255, 255, 255)
Quick_Drop.TextSize = 15.000
Quick_Drop.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Quick_Drop.TextStrokeTransparency = 0.900
Quick_Drop.TextWrapped = true

CheckBox2_2.Name = "CheckBox2"
CheckBox2_2.Parent = Quick_Drop
CheckBox2_2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
CheckBox2_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
CheckBox2_2.Position = UDim2.new(-0.338, 0, 0, 0)
CheckBox2_2.Size = UDim2.new(0.226999998, 0, 1, 0)
CheckBox2_2.Visible = false
CheckBox2_2.Font = Enum.Font.Gotham
CheckBox2_2.Text = "X"
CheckBox2_2.TextColor3 = Color3.fromRGB(255, 0, 0)
CheckBox2_2.TextSize = 16.000
CheckBox2_2.TextWrapped = true

CheckBox1_2.Name = "CheckBox1"
CheckBox1_2.Parent = Quick_Drop
CheckBox1_2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
CheckBox1_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
CheckBox1_2.Position = UDim2.new(-0.338391006, 0, 0, 0)
CheckBox1_2.Size = UDim2.new(0.227391034, 0, 1, 0)
CheckBox1_2.Font = Enum.Font.Gotham
CheckBox1_2.Text = ""
CheckBox1_2.TextColor3 = Color3.fromRGB(255, 0, 0)
CheckBox1_2.TextSize = 16.000
CheckBox1_2.TextTransparency = 1.000

Display_AutoStomp1.Name = "Display_AutoStomp1"
Display_AutoStomp1.Parent = Display_Main_Frame
Display_AutoStomp1.Active = false
Display_AutoStomp1.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
Display_AutoStomp1.BorderColor3 = Color3.fromRGB(186, 186, 186)
Display_AutoStomp1.BorderSizePixel = 2
Display_AutoStomp1.Position = UDim2.new(0.0127208577, 0, 0.384010613, 0)
Display_AutoStomp1.Selectable = false
Display_AutoStomp1.Size = UDim2.new(0.27369082, 0, 0.0948373005, 0)
Display_AutoStomp1.Font = Enum.Font.Cartoon
Display_AutoStomp1.Text = ""
Display_AutoStomp1.TextColor3 = Color3.fromRGB(255, 255, 255)
Display_AutoStomp1.TextSize = 16.000

Auto_Stomp.Name = "Auto_Stomp"
Auto_Stomp.Parent = Display_AutoStomp1
Auto_Stomp.Active = false
Auto_Stomp.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Auto_Stomp.BorderColor3 = Color3.fromRGB(0, 0, 0)
Auto_Stomp.Position = UDim2.new(0.251424521, 0, 0, 0)
Auto_Stomp.Selectable = false
Auto_Stomp.Size = UDim2.new(0.743000031, 0, 0.980085075, 0)
Auto_Stomp.Font = Enum.Font.SourceSansSemibold
Auto_Stomp.Text = "AUTO STOMP"
Auto_Stomp.TextColor3 = Color3.fromRGB(255, 255, 255)
Auto_Stomp.TextSize = 16.000
Auto_Stomp.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Auto_Stomp.TextStrokeTransparency = 0.900

CheckBox2_3.Name = "CheckBox2"
CheckBox2_3.Parent = Auto_Stomp
CheckBox2_3.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
CheckBox2_3.BorderColor3 = Color3.fromRGB(0, 0, 0)
CheckBox2_3.Position = UDim2.new(-0.338, 0, 0, 0)
CheckBox2_3.Size = UDim2.new(0.226999998, 0, 1, 0)
CheckBox2_3.Visible = false
CheckBox2_3.Font = Enum.Font.Gotham
CheckBox2_3.Text = "X"
CheckBox2_3.TextColor3 = Color3.fromRGB(255, 0, 0)
CheckBox2_3.TextSize = 16.000
CheckBox2_3.TextWrapped = true

CheckBox1_3.Name = "CheckBox1"
CheckBox1_3.Parent = Auto_Stomp
CheckBox1_3.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
CheckBox1_3.BorderColor3 = Color3.fromRGB(0, 0, 0)
CheckBox1_3.Position = UDim2.new(-0.338391006, 0, 0, 0)
CheckBox1_3.Size = UDim2.new(0.227391034, 0, 1, 0)
CheckBox1_3.Font = Enum.Font.Gotham
CheckBox1_3.Text = ""
CheckBox1_3.TextColor3 = Color3.fromRGB(255, 0, 0)
CheckBox1_3.TextSize = 16.000
CheckBox1_3.TextTransparency = 1.000

WS_V1.Name = "WS_V1"
WS_V1.Parent = Display_Main_Frame
WS_V1.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
WS_V1.BorderColor3 = Color3.fromRGB(0, 0, 0)
WS_V1.Position = UDim2.new(0.540538251, 0, 0.39214164, 0)
WS_V1.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
WS_V1.Font = Enum.Font.SourceSansSemibold
WS_V1.Text = "SPEED V1 (Q)"
WS_V1.TextColor3 = Color3.fromRGB(255, 255, 255)
WS_V1.TextSize = 16.000
WS_V1.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
WS_V1.TextStrokeTransparency = 0.900
WS_V1.TextWrapped = true

Inf_Jump.Name = "Inf_Jump"
Inf_Jump.Parent = Display_Main_Frame
Inf_Jump.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Inf_Jump.BorderColor3 = Color3.fromRGB(0, 0, 0)
Inf_Jump.Position = UDim2.new(0.769352496, 0, 0.0636493117, 0)
Inf_Jump.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Inf_Jump.Font = Enum.Font.SourceSansSemibold
Inf_Jump.Text = "INFINITE JUMP"
Inf_Jump.TextColor3 = Color3.fromRGB(255, 255, 255)
Inf_Jump.TextSize = 16.000
Inf_Jump.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Inf_Jump.TextStrokeTransparency = 0.900
Inf_Jump.TextWrapped = true

Gravity.Name = "Gravity"
Gravity.Parent = Display_Main_Frame
Gravity.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Gravity.BorderColor3 = Color3.fromRGB(0, 0, 0)
Gravity.Position = UDim2.new(0.77151078, 0, 0.39214164, 0)
Gravity.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Gravity.Font = Enum.Font.SourceSansSemibold
Gravity.Text = "LOW GRAVITY"
Gravity.TextColor3 = Color3.fromRGB(255, 255, 255)
Gravity.TextSize = 16.000
Gravity.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Gravity.TextStrokeTransparency = 0.900
Gravity.TextWrapped = true

Ragdoll_Reset.Name = "Ragdoll_Reset"
Ragdoll_Reset.Parent = Display_Main_Frame
Ragdoll_Reset.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Ragdoll_Reset.BorderColor3 = Color3.fromRGB(0, 0, 0)
Ragdoll_Reset.Position = UDim2.new(0.307702988, 0, 0.39214164, 0)
Ragdoll_Reset.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Ragdoll_Reset.Font = Enum.Font.SourceSansSemibold
Ragdoll_Reset.Text = "RAG-RESET V2"
Ragdoll_Reset.TextColor3 = Color3.fromRGB(255, 255, 255)
Ragdoll_Reset.TextSize = 16.000
Ragdoll_Reset.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Ragdoll_Reset.TextStrokeTransparency = 0.900
Ragdoll_Reset.TextWrapped = true

Invisible.Name = "Invisible"
Invisible.Parent = Display_Main_Frame
Invisible.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Invisible.BorderColor3 = Color3.fromRGB(0, 0, 0)
Invisible.Position = UDim2.new(0.77151078, 0, 0.228168443, 0)
Invisible.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Invisible.Font = Enum.Font.SourceSansSemibold
Invisible.Text = "INVISIBLE"
Invisible.TextColor3 = Color3.fromRGB(255, 255, 255)
Invisible.TextSize = 16.000
Invisible.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Invisible.TextStrokeTransparency = 0.900
Invisible.TextWrapped = true

Anti_Stomp.Name = "Anti_Stomp"
Anti_Stomp.Parent = Display_Main_Frame
Anti_Stomp.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Anti_Stomp.BorderColor3 = Color3.fromRGB(0, 0, 0)
Anti_Stomp.Position = UDim2.new(0.539847314, 0, 0.556114912, 0)
Anti_Stomp.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Anti_Stomp.Font = Enum.Font.SourceSansSemibold
Anti_Stomp.Text = "ANTI STOMP"
Anti_Stomp.TextColor3 = Color3.fromRGB(255, 255, 255)
Anti_Stomp.TextSize = 16.000
Anti_Stomp.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Anti_Stomp.TextStrokeTransparency = 0.900
Anti_Stomp.TextWrapped = true

Melee_Reach.Name = "Melee_Reach"
Melee_Reach.Parent = Display_Main_Frame
Melee_Reach.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Melee_Reach.BorderColor3 = Color3.fromRGB(0, 0, 0)
Melee_Reach.Position = UDim2.new(0.307702988, 0, 0.720088482, 0)
Melee_Reach.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Melee_Reach.Font = Enum.Font.SourceSansSemibold
Melee_Reach.Text = "MELEE REACH"
Melee_Reach.TextColor3 = Color3.fromRGB(255, 255, 255)
Melee_Reach.TextSize = 16.000
Melee_Reach.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Melee_Reach.TextStrokeTransparency = 0.900
Melee_Reach.TextWrapped = true

Kill_Aura.Name = "Kill_Aura"
Kill_Aura.Parent = Display_Main_Frame
Kill_Aura.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Kill_Aura.BorderColor3 = Color3.fromRGB(0, 0, 0)
Kill_Aura.Position = UDim2.new(0.774589956, 0, 0.556114912, 0)
Kill_Aura.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Kill_Aura.Font = Enum.Font.SourceSansSemibold
Kill_Aura.Text = "KILL AURA"
Kill_Aura.TextColor3 = Color3.fromRGB(255, 255, 255)
Kill_Aura.TextSize = 16.000
Kill_Aura.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Kill_Aura.TextStrokeTransparency = 0.900
Kill_Aura.TextWrapped = true

Fly.Name = "Fly"
Fly.Parent = Display_Main_Frame
Fly.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Fly.BackgroundTransparency = 0.500
Fly.BorderColor3 = Color3.fromRGB(0, 0, 0)
Fly.Position = UDim2.new(0.77151078, 0, 0.720088482, 0)
Fly.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Fly.Font = Enum.Font.Cartoon
Fly.Text = ""
Fly.TextColor3 = Color3.fromRGB(255, 255, 255)
Fly.TextSize = 16.000
Fly.TextWrapped = true

GetTools.Name = "GetTools"
GetTools.Parent = Display_Main_Frame
GetTools.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
GetTools.BorderColor3 = Color3.fromRGB(0, 0, 0)
GetTools.Position = UDim2.new(0.307702988, 0, 0.556114912, 0)
GetTools.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
GetTools.Font = Enum.Font.SourceSansSemibold
GetTools.Text = "KNIFE + LPICK"
GetTools.TextColor3 = Color3.fromRGB(255, 255, 255)
GetTools.TextSize = 16.000
GetTools.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
GetTools.TextStrokeTransparency = 0.900
GetTools.TextWrapped = true

Autorob.Name = "Autorob"
Autorob.Parent = Display_Main_Frame
Autorob.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Autorob.BorderColor3 = Color3.fromRGB(0, 0, 0)
Autorob.Position = UDim2.new(0.540538251, 0, 0.720088482, 0)
Autorob.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Autorob.Font = Enum.Font.SourceSansSemibold
Autorob.Text = "AUTOROB"
Autorob.TextColor3 = Color3.fromRGB(255, 255, 255)
Autorob.TextSize = 16.000
Autorob.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Autorob.TextStrokeTransparency = 0.900
Autorob.TextWrapped = true

Noclip.Name = "Noclip"
Noclip.Parent = Display_Main_Frame
Noclip.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Noclip.BorderColor3 = Color3.fromRGB(0, 0, 0)
Noclip.Position = UDim2.new(0.540538251, 0, 0.0641951337, 0)
Noclip.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Noclip.Font = Enum.Font.SourceSansSemibold
Noclip.Text = "NOCLIP (TOGGLE C)"
Noclip.TextColor3 = Color3.fromRGB(255, 255, 255)
Noclip.TextSize = 14.000
Noclip.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Noclip.TextStrokeTransparency = 0.900
Noclip.TextWrapped = true

Fly1.Name = "Fly1"
Fly1.Parent = Display_Main_Frame
Fly1.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Fly1.BorderColor3 = Color3.fromRGB(0, 0, 0)
Fly1.Position = UDim2.new(0.307702988, 0, 0.0641951337, 0)
Fly1.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Fly1.Font = Enum.Font.SourceSansSemibold
Fly1.Text = "FLY (TOGGLE X)"
Fly1.TextColor3 = Color3.fromRGB(255, 255, 255)
Fly1.TextSize = 16.000
Fly1.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Fly1.TextStrokeTransparency = 0.900
Fly1.TextWrapped = true

UnGod_Mode.Name = "UnGod_Mode"
UnGod_Mode.Parent = Display_Main_Frame
UnGod_Mode.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
UnGod_Mode.BorderColor3 = Color3.fromRGB(0, 0, 0)
UnGod_Mode.Position = UDim2.new(0.540538251, 0, 0.228168443, 0)
UnGod_Mode.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
UnGod_Mode.Font = Enum.Font.SourceSansSemibold
UnGod_Mode.Text = "UNGOD MODE"
UnGod_Mode.TextColor3 = Color3.fromRGB(255, 255, 255)
UnGod_Mode.TextSize = 16.000
UnGod_Mode.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
UnGod_Mode.TextStrokeTransparency = 0.900
UnGod_Mode.TextWrapped = true

God_Mode.Name = "God_Mode"
God_Mode.Parent = Display_Main_Frame
God_Mode.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
God_Mode.BorderColor3 = Color3.fromRGB(0, 0, 0)
God_Mode.Position = UDim2.new(0.307702988, 0, 0.228168443, 0)
God_Mode.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
God_Mode.Font = Enum.Font.SourceSansSemibold
God_Mode.Text = "GOD MODE"
God_Mode.TextColor3 = Color3.fromRGB(255, 255, 255)
God_Mode.TextSize = 16.000
God_Mode.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
God_Mode.TextStrokeTransparency = 0.900
God_Mode.TextWrapped = true

Display_ClickTP.Name = "Display_ClickTP"
Display_ClickTP.Parent = Display_Main_Frame
Display_ClickTP.Active = false
Display_ClickTP.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
Display_ClickTP.BorderColor3 = Color3.fromRGB(186, 186, 186)
Display_ClickTP.BorderSizePixel = 2
Display_ClickTP.Position = UDim2.new(0.0127208577, 0, 0.554998875, 0)
Display_ClickTP.Selectable = false
Display_ClickTP.Size = UDim2.new(0.27369082, 0, 0.0948373005, 0)
Display_ClickTP.Font = Enum.Font.Cartoon
Display_ClickTP.Text = ""
Display_ClickTP.TextColor3 = Color3.fromRGB(255, 255, 255)
Display_ClickTP.TextSize = 15.000

ClickTP.Name = "ClickTP"
ClickTP.Parent = Display_ClickTP
ClickTP.Active = false
ClickTP.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
ClickTP.BorderColor3 = Color3.fromRGB(0, 0, 0)
ClickTP.Position = UDim2.new(0.251424521, 0, 0, 0)
ClickTP.Selectable = false
ClickTP.Size = UDim2.new(0.743000031, 0, 0.980085075, 0)
ClickTP.Font = Enum.Font.SourceSansSemibold
ClickTP.Text = "CLICK TP (TAB)"
ClickTP.TextColor3 = Color3.fromRGB(255, 255, 255)
ClickTP.TextSize = 16.000
ClickTP.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
ClickTP.TextStrokeTransparency = 0.900

CheckBox2_4.Name = "CheckBox2"
CheckBox2_4.Parent = ClickTP
CheckBox2_4.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
CheckBox2_4.BorderColor3 = Color3.fromRGB(0, 0, 0)
CheckBox2_4.Position = UDim2.new(-0.338, 0, 0, 0)
CheckBox2_4.Size = UDim2.new(0.226999998, 0, 1, 0)
CheckBox2_4.Visible = false
CheckBox2_4.Font = Enum.Font.Gotham
CheckBox2_4.Text = "X"
CheckBox2_4.TextColor3 = Color3.fromRGB(255, 0, 0)
CheckBox2_4.TextSize = 16.000
CheckBox2_4.TextWrapped = true

CheckBox1_4.Name = "CheckBox1"
CheckBox1_4.Parent = ClickTP
CheckBox1_4.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
CheckBox1_4.BorderColor3 = Color3.fromRGB(0, 0, 0)
CheckBox1_4.Position = UDim2.new(-0.338391006, 0, 0, 0)
CheckBox1_4.Size = UDim2.new(0.227391034, 0, 1, 0)
CheckBox1_4.Font = Enum.Font.Gotham
CheckBox1_4.Text = ""
CheckBox1_4.TextColor3 = Color3.fromRGB(255, 0, 0)
CheckBox1_4.TextSize = 16.000
CheckBox1_4.TextTransparency = 1.000

Global.Name = "Global"
Global.Parent = Main_First_2
Global.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Global.BorderColor3 = Color3.fromRGB(255, 255, 255)
Global.BorderSizePixel = 0
Global.Position = UDim2.new(0.657369256, 0, 0.0163156148, 0)
Global.Size = UDim2.new(0.118000001, 0, 0.0909999982, 0)
Global.Font = Enum.Font.SourceSansBold
Global.Text = "GLOBAL"
Global.TextColor3 = Color3.fromRGB(255, 255, 255)
Global.TextSize = 16.000
Global.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Global.TextStrokeTransparency = 0.800
Global.TextWrapped = true

Display_Global_Frame.Name = "Display_Global_Frame"
Display_Global_Frame.Parent = Main_First_2
Display_Global_Frame.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
Display_Global_Frame.BorderColor3 = Color3.fromRGB(30, 30, 30)
Display_Global_Frame.BorderSizePixel = 0
Display_Global_Frame.LayoutOrder = 10
Display_Global_Frame.Position = UDim2.new(5.46497105e-08, 0, 0.117310651, 0)
Display_Global_Frame.Size = UDim2.new(0.999999881, 0, 0.882689536, 0)
Display_Global_Frame.Visible = false

Gunshop_1TP.Name = "Gunshop_1TP"
Gunshop_1TP.Parent = Display_Global_Frame
Gunshop_1TP.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Gunshop_1TP.BorderColor3 = Color3.fromRGB(0, 0, 0)
Gunshop_1TP.Position = UDim2.new(0.319228441, 0, 0.379619569, 0)
Gunshop_1TP.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Gunshop_1TP.Font = Enum.Font.SourceSansSemibold
Gunshop_1TP.Text = "Gunshop 1 TP"
Gunshop_1TP.TextColor3 = Color3.fromRGB(255, 255, 255)
Gunshop_1TP.TextSize = 16.000
Gunshop_1TP.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Gunshop_1TP.TextStrokeTransparency = 0.900
Gunshop_1TP.TextWrapped = true

Boxing_TP.Name = "Boxing_TP"
Boxing_TP.Parent = Display_Global_Frame
Boxing_TP.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Boxing_TP.BorderColor3 = Color3.fromRGB(0, 0, 0)
Boxing_TP.Position = UDim2.new(0.548042655, 0, 0.0511272326, 0)
Boxing_TP.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Boxing_TP.Font = Enum.Font.SourceSansSemibold
Boxing_TP.Text = "BOXING CLUB TP"
Boxing_TP.TextColor3 = Color3.fromRGB(255, 255, 255)
Boxing_TP.TextSize = 16.000
Boxing_TP.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Boxing_TP.TextStrokeTransparency = 0.900
Boxing_TP.TextWrapped = true

SEWER_TP.Name = "SEWER_TP"
SEWER_TP.Parent = Display_Global_Frame
SEWER_TP.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
SEWER_TP.BorderColor3 = Color3.fromRGB(0, 0, 0)
SEWER_TP.Position = UDim2.new(0.550200939, 0, 0.379619569, 0)
SEWER_TP.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
SEWER_TP.Font = Enum.Font.SourceSansSemibold
SEWER_TP.Text = "SEWER TP"
SEWER_TP.TextColor3 = Color3.fromRGB(255, 255, 255)
SEWER_TP.TextSize = 16.000
SEWER_TP.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
SEWER_TP.TextStrokeTransparency = 0.900
SEWER_TP.TextWrapped = true

Chat_Logs.Name = "Chat_Logs"
Chat_Logs.Parent = Display_Global_Frame
Chat_Logs.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Chat_Logs.BorderColor3 = Color3.fromRGB(0, 0, 0)
Chat_Logs.Position = UDim2.new(0.0164062977, 0, 0.379619569, 0)
Chat_Logs.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Chat_Logs.Font = Enum.Font.SourceSansSemibold
Chat_Logs.Text = "CHAT LOGS V2"
Chat_Logs.TextColor3 = Color3.fromRGB(255, 255, 255)
Chat_Logs.TextSize = 16.000
Chat_Logs.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Chat_Logs.TextStrokeTransparency = 0.900
Chat_Logs.TextWrapped = true

BAT_SILENCER_TP.Name = "BAT_SILENCER_TP"
BAT_SILENCER_TP.Parent = Display_Global_Frame
BAT_SILENCER_TP.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
BAT_SILENCER_TP.BorderColor3 = Color3.fromRGB(0, 0, 0)
BAT_SILENCER_TP.Position = UDim2.new(0.550200939, 0, 0.215646371, 0)
BAT_SILENCER_TP.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
BAT_SILENCER_TP.Font = Enum.Font.SourceSansSemibold
BAT_SILENCER_TP.Text = "BASEBALL BAT TP"
BAT_SILENCER_TP.TextColor3 = Color3.fromRGB(255, 255, 255)
BAT_SILENCER_TP.TextSize = 15.000
BAT_SILENCER_TP.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
BAT_SILENCER_TP.TextStrokeTransparency = 0.900
BAT_SILENCER_TP.TextWrapped = true

UFO_TP.Name = "UFO_TP"
UFO_TP.Parent = Display_Global_Frame
UFO_TP.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
UFO_TP.BorderColor3 = Color3.fromRGB(0, 0, 0)
UFO_TP.Position = UDim2.new(0.550200939, 0, 0.543592811, 0)
UFO_TP.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
UFO_TP.Font = Enum.Font.SourceSansSemibold
UFO_TP.Text = "UFO HILL TP"
UFO_TP.TextColor3 = Color3.fromRGB(255, 255, 255)
UFO_TP.TextSize = 16.000
UFO_TP.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
UFO_TP.TextStrokeTransparency = 0.900
UFO_TP.TextWrapped = true

Super_Zoom.Name = "Super_Zoom"
Super_Zoom.Parent = Display_Global_Frame
Super_Zoom.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Super_Zoom.BorderColor3 = Color3.fromRGB(0, 0, 0)
Super_Zoom.Position = UDim2.new(0.0164062977, 0, 0.707566381, 0)
Super_Zoom.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Super_Zoom.Font = Enum.Font.SourceSansSemibold
Super_Zoom.Text = "SUPER ZOOM"
Super_Zoom.TextColor3 = Color3.fromRGB(255, 255, 255)
Super_Zoom.TextSize = 16.000
Super_Zoom.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Super_Zoom.TextStrokeTransparency = 0.900
Super_Zoom.TextWrapped = true

Gunshop2_TP.Name = "Gunshop2_TP"
Gunshop2_TP.Parent = Display_Global_Frame
Gunshop2_TP.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Gunshop2_TP.BorderColor3 = Color3.fromRGB(0, 0, 0)
Gunshop2_TP.Position = UDim2.new(0.319228441, 0, 0.543592811, 0)
Gunshop2_TP.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Gunshop2_TP.Font = Enum.Font.SourceSansSemibold
Gunshop2_TP.Text = "Gunshop 2 TP"
Gunshop2_TP.TextColor3 = Color3.fromRGB(255, 255, 255)
Gunshop2_TP.TextSize = 16.000
Gunshop2_TP.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Gunshop2_TP.TextStrokeTransparency = 0.900
Gunshop2_TP.TextWrapped = true

HoodFitness_TP.Name = "HoodFitness_TP"
HoodFitness_TP.Parent = Display_Global_Frame
HoodFitness_TP.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
HoodFitness_TP.BorderColor3 = Color3.fromRGB(0, 0, 0)
HoodFitness_TP.Position = UDim2.new(0.550200939, 0, 0.707566381, 0)
HoodFitness_TP.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
HoodFitness_TP.Font = Enum.Font.SourceSansSemibold
HoodFitness_TP.Text = "FITNESS TP"
HoodFitness_TP.TextColor3 = Color3.fromRGB(255, 255, 255)
HoodFitness_TP.TextSize = 16.000
HoodFitness_TP.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
HoodFitness_TP.TextStrokeTransparency = 0.900
HoodFitness_TP.TextWrapped = true

Anti_Pepper_Snowball.Name = "Anti_Pepper_Snowball"
Anti_Pepper_Snowball.Parent = Display_Global_Frame
Anti_Pepper_Snowball.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Anti_Pepper_Snowball.BorderColor3 = Color3.fromRGB(0, 0, 0)
Anti_Pepper_Snowball.Position = UDim2.new(0.0164062977, 0, 0.543592811, 0)
Anti_Pepper_Snowball.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Anti_Pepper_Snowball.Font = Enum.Font.SourceSansSemibold
Anti_Pepper_Snowball.Text = "ANTI PEPPER + SNOWBALL EFFECT"
Anti_Pepper_Snowball.TextColor3 = Color3.fromRGB(255, 255, 255)
Anti_Pepper_Snowball.TextScaled = true
Anti_Pepper_Snowball.TextSize = 13.000
Anti_Pepper_Snowball.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Anti_Pepper_Snowball.TextStrokeTransparency = 0.900
Anti_Pepper_Snowball.TextWrapped = true

AdminBase_TP.Name = "AdminBase_TP"
AdminBase_TP.Parent = Display_Global_Frame
AdminBase_TP.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
AdminBase_TP.BorderColor3 = Color3.fromRGB(0, 0, 0)
AdminBase_TP.Position = UDim2.new(0.319228441, 0, 0.707566381, 0)
AdminBase_TP.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
AdminBase_TP.Font = Enum.Font.SourceSansSemibold
AdminBase_TP.Text = "Admin Base TP"
AdminBase_TP.TextColor3 = Color3.fromRGB(255, 255, 255)
AdminBase_TP.TextSize = 16.000
AdminBase_TP.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
AdminBase_TP.TextStrokeTransparency = 0.900
AdminBase_TP.TextWrapped = true

Prison_TP.Name = "Prison_TP"
Prison_TP.Parent = Display_Global_Frame
Prison_TP.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Prison_TP.BorderColor3 = Color3.fromRGB(0, 0, 0)
Prison_TP.Position = UDim2.new(0.319228441, 0, 0.0516730547, 0)
Prison_TP.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Prison_TP.Font = Enum.Font.SourceSansSemibold
Prison_TP.Text = "PRISON TP"
Prison_TP.TextColor3 = Color3.fromRGB(255, 255, 255)
Prison_TP.TextSize = 15.000
Prison_TP.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Prison_TP.TextStrokeTransparency = 0.900
Prison_TP.TextWrapped = true

Toggle_Fog.Name = "Toggle_Fog"
Toggle_Fog.Parent = Display_Global_Frame
Toggle_Fog.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Toggle_Fog.BorderColor3 = Color3.fromRGB(0, 0, 0)
Toggle_Fog.Position = UDim2.new(0.0164062977, 0, 0.0516730547, 0)
Toggle_Fog.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Toggle_Fog.Font = Enum.Font.SourceSansSemibold
Toggle_Fog.Text = "TOGGLE FOG"
Toggle_Fog.TextColor3 = Color3.fromRGB(255, 255, 255)
Toggle_Fog.TextSize = 16.000
Toggle_Fog.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Toggle_Fog.TextStrokeTransparency = 0.900
Toggle_Fog.TextWrapped = true

Bank_TP.Name = "Bank_TP"
Bank_TP.Parent = Display_Global_Frame
Bank_TP.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Bank_TP.BorderColor3 = Color3.fromRGB(0, 0, 0)
Bank_TP.Position = UDim2.new(0.319228441, 0, 0.215646371, 0)
Bank_TP.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Bank_TP.Font = Enum.Font.SourceSansSemibold
Bank_TP.Text = "BANK TP"
Bank_TP.TextColor3 = Color3.fromRGB(255, 255, 255)
Bank_TP.TextSize = 16.000
Bank_TP.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Bank_TP.TextStrokeTransparency = 0.900
Bank_TP.TextWrapped = true

Toggle_Brightness.Name = "Toggle_Brightness"
Toggle_Brightness.Parent = Display_Global_Frame
Toggle_Brightness.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Toggle_Brightness.BorderColor3 = Color3.fromRGB(0, 0, 0)
Toggle_Brightness.Position = UDim2.new(0.0164062977, 0, 0.215646371, 0)
Toggle_Brightness.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Toggle_Brightness.Font = Enum.Font.SourceSansSemibold
Toggle_Brightness.Text = "TOGGLE BRIGHT"
Toggle_Brightness.TextColor3 = Color3.fromRGB(255, 255, 255)
Toggle_Brightness.TextSize = 16.000
Toggle_Brightness.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Toggle_Brightness.TextStrokeTransparency = 0.900
Toggle_Brightness.TextWrapped = true

PhoneShop_TP.Name = "PhoneShop_TP"
PhoneShop_TP.Parent = Display_Global_Frame
PhoneShop_TP.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
PhoneShop_TP.BorderColor3 = Color3.fromRGB(0, 0, 0)
PhoneShop_TP.Position = UDim2.new(0.778810203, 0, 0.0511272326, 0)
PhoneShop_TP.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
PhoneShop_TP.Font = Enum.Font.SourceSansSemibold
PhoneShop_TP.Text = "PHONE SHOP TP"
PhoneShop_TP.TextColor3 = Color3.fromRGB(255, 255, 255)
PhoneShop_TP.TextSize = 16.000
PhoneShop_TP.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
PhoneShop_TP.TextStrokeTransparency = 0.900
PhoneShop_TP.TextWrapped = true

Save_Pos.Name = "Save_Pos"
Save_Pos.Parent = Display_Global_Frame
Save_Pos.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Save_Pos.BorderColor3 = Color3.fromRGB(0, 0, 0)
Save_Pos.Position = UDim2.new(0.780968487, 0, 0.215646371, 0)
Save_Pos.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Save_Pos.Font = Enum.Font.SourceSansSemibold
Save_Pos.Text = "SAVE POS"
Save_Pos.TextColor3 = Color3.fromRGB(255, 255, 255)
Save_Pos.TextSize = 16.000
Save_Pos.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Save_Pos.TextStrokeTransparency = 0.900
Save_Pos.TextWrapped = true

Load_Pos.Name = "Load_Pos"
Load_Pos.Parent = Display_Global_Frame
Load_Pos.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Load_Pos.BorderColor3 = Color3.fromRGB(0, 0, 0)
Load_Pos.Position = UDim2.new(0.780968487, 0, 0.379619569, 0)
Load_Pos.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Load_Pos.Font = Enum.Font.SourceSansSemibold
Load_Pos.Text = "LOAD POS"
Load_Pos.TextColor3 = Color3.fromRGB(255, 255, 255)
Load_Pos.TextSize = 16.000
Load_Pos.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Load_Pos.TextStrokeTransparency = 0.900
Load_Pos.TextWrapped = true

Anti_Stomp_2.Name = "Anti_Stomp"
Anti_Stomp_2.Parent = Display_Global_Frame
Anti_Stomp_2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Anti_Stomp_2.BackgroundTransparency = 0.500
Anti_Stomp_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
Anti_Stomp_2.Position = UDim2.new(0.780968487, 0, 0.543592811, 0)
Anti_Stomp_2.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Anti_Stomp_2.Font = Enum.Font.SourceSansSemibold
Anti_Stomp_2.Text = ""
Anti_Stomp_2.TextColor3 = Color3.fromRGB(255, 255, 255)
Anti_Stomp_2.TextScaled = true
Anti_Stomp_2.TextSize = 16.000
Anti_Stomp_2.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Anti_Stomp_2.TextStrokeTransparency = 0.900
Anti_Stomp_2.TextWrapped = true

Fly_2.Name = "Fly"
Fly_2.Parent = Display_Global_Frame
Fly_2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Fly_2.BackgroundTransparency = 0.500
Fly_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
Fly_2.Position = UDim2.new(0.780968487, 0, 0.707566381, 0)
Fly_2.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Fly_2.Font = Enum.Font.Cartoon
Fly_2.Text = ""
Fly_2.TextColor3 = Color3.fromRGB(255, 255, 255)
Fly_2.TextSize = 16.000
Fly_2.TextWrapped = true

Melee_Reach_2.Name = "Melee_Reach"
Melee_Reach_2.Parent = Display_Global_Frame
Melee_Reach_2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Melee_Reach_2.BackgroundTransparency = 0.500
Melee_Reach_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
Melee_Reach_2.Position = UDim2.new(0.0164062977, 0, 0.869055271, 0)
Melee_Reach_2.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Melee_Reach_2.Font = Enum.Font.SourceSansLight
Melee_Reach_2.Text = "AUDIO-ID (WIP)"
Melee_Reach_2.TextColor3 = Color3.fromRGB(153, 153, 153)
Melee_Reach_2.TextSize = 16.000
Melee_Reach_2.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Melee_Reach_2.TextStrokeTransparency = 0.900
Melee_Reach_2.TextWrapped = true

Display_Misc_Frame.Name = "Display_Misc_Frame"
Display_Misc_Frame.Parent = Main_First_2
Display_Misc_Frame.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
Display_Misc_Frame.BorderColor3 = Color3.fromRGB(30, 30, 30)
Display_Misc_Frame.BorderSizePixel = 0
Display_Misc_Frame.LayoutOrder = 10
Display_Misc_Frame.Position = UDim2.new(5.46497105e-08, 0, 0.117310651, 0)
Display_Misc_Frame.Size = UDim2.new(0.999999881, 0, 0.882689536, 0)
Display_Misc_Frame.Visible = false

Tools_While_Cuffed.Name = "Tools_While_Cuffed"
Tools_While_Cuffed.Parent = Display_Misc_Frame
Tools_While_Cuffed.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Tools_While_Cuffed.BorderColor3 = Color3.fromRGB(0, 0, 0)
Tools_While_Cuffed.Position = UDim2.new(0.527297497, 0, 0.379619569, 0)
Tools_While_Cuffed.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Tools_While_Cuffed.Font = Enum.Font.SourceSansSemibold
Tools_While_Cuffed.Text = "TOOLS WHILE CUFFED"
Tools_While_Cuffed.TextColor3 = Color3.fromRGB(255, 255, 255)
Tools_While_Cuffed.TextScaled = true
Tools_While_Cuffed.TextSize = 16.000
Tools_While_Cuffed.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Tools_While_Cuffed.TextStrokeTransparency = 0.900
Tools_While_Cuffed.TextWrapped = true

Boxing_TP_2.Name = "Boxing_TP"
Boxing_TP_2.Parent = Display_Misc_Frame
Boxing_TP_2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Boxing_TP_2.BackgroundTransparency = 0.500
Boxing_TP_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
Boxing_TP_2.Position = UDim2.new(0.756111741, 0, 0.0511272326, 0)
Boxing_TP_2.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Boxing_TP_2.Font = Enum.Font.SourceSansSemibold
Boxing_TP_2.Text = ""
Boxing_TP_2.TextColor3 = Color3.fromRGB(255, 255, 255)
Boxing_TP_2.TextSize = 16.000
Boxing_TP_2.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Boxing_TP_2.TextStrokeTransparency = 0.900
Boxing_TP_2.TextWrapped = true

SEWER_TP_2.Name = "SEWER_TP"
SEWER_TP_2.Parent = Display_Misc_Frame
SEWER_TP_2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
SEWER_TP_2.BackgroundTransparency = 0.500
SEWER_TP_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
SEWER_TP_2.Position = UDim2.new(0.758270025, 0, 0.379619569, 0)
SEWER_TP_2.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
SEWER_TP_2.Font = Enum.Font.SourceSansSemibold
SEWER_TP_2.Text = ""
SEWER_TP_2.TextColor3 = Color3.fromRGB(255, 255, 255)
SEWER_TP_2.TextSize = 16.000
SEWER_TP_2.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
SEWER_TP_2.TextStrokeTransparency = 0.900
SEWER_TP_2.TextWrapped = true

Unjail.Name = "Unjail"
Unjail.Parent = Display_Misc_Frame
Unjail.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Unjail.BorderColor3 = Color3.fromRGB(0, 0, 0)
Unjail.Position = UDim2.new(0.298245311, 0, 0.379619569, 0)
Unjail.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Unjail.Font = Enum.Font.SourceSansSemibold
Unjail.Text = "UN-JAIL V2"
Unjail.TextColor3 = Color3.fromRGB(255, 255, 255)
Unjail.TextSize = 16.000
Unjail.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Unjail.TextStrokeTransparency = 0.900
Unjail.TextWrapped = true

BAT_SILENCER_TP_2.Name = "BAT_SILENCER_TP"
BAT_SILENCER_TP_2.Parent = Display_Misc_Frame
BAT_SILENCER_TP_2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
BAT_SILENCER_TP_2.BackgroundTransparency = 0.500
BAT_SILENCER_TP_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
BAT_SILENCER_TP_2.Position = UDim2.new(0.758270025, 0, 0.215646371, 0)
BAT_SILENCER_TP_2.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
BAT_SILENCER_TP_2.Font = Enum.Font.SourceSansSemibold
BAT_SILENCER_TP_2.Text = ""
BAT_SILENCER_TP_2.TextColor3 = Color3.fromRGB(255, 255, 255)
BAT_SILENCER_TP_2.TextSize = 15.000
BAT_SILENCER_TP_2.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
BAT_SILENCER_TP_2.TextStrokeTransparency = 0.900
BAT_SILENCER_TP_2.TextWrapped = true

UFO_TP_2.Name = "UFO_TP"
UFO_TP_2.Parent = Display_Misc_Frame
UFO_TP_2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
UFO_TP_2.BackgroundTransparency = 0.500
UFO_TP_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
UFO_TP_2.Position = UDim2.new(0.758270025, 0, 0.543592811, 0)
UFO_TP_2.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
UFO_TP_2.Font = Enum.Font.SourceSansSemibold
UFO_TP_2.Text = ""
UFO_TP_2.TextColor3 = Color3.fromRGB(255, 255, 255)
UFO_TP_2.TextSize = 16.000
UFO_TP_2.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
UFO_TP_2.TextStrokeTransparency = 0.900
UFO_TP_2.TextWrapped = true

Rejoin.Name = "Rejoin"
Rejoin.Parent = Display_Misc_Frame
Rejoin.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Rejoin.BorderColor3 = Color3.fromRGB(0, 0, 0)
Rejoin.Position = UDim2.new(0.527297497, 0, 0.543592811, 0)
Rejoin.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Rejoin.Font = Enum.Font.SourceSansSemibold
Rejoin.Text = "REJOIN SERVER"
Rejoin.TextColor3 = Color3.fromRGB(255, 255, 255)
Rejoin.TextSize = 16.000
Rejoin.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Rejoin.TextStrokeTransparency = 0.900
Rejoin.TextWrapped = true

HoodFitness_TP_2.Name = "HoodFitness_TP"
HoodFitness_TP_2.Parent = Display_Misc_Frame
HoodFitness_TP_2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
HoodFitness_TP_2.BackgroundTransparency = 0.500
HoodFitness_TP_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
HoodFitness_TP_2.Position = UDim2.new(0.758270025, 0, 0.707566381, 0)
HoodFitness_TP_2.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
HoodFitness_TP_2.Font = Enum.Font.SourceSansSemibold
HoodFitness_TP_2.Text = ""
HoodFitness_TP_2.TextColor3 = Color3.fromRGB(255, 255, 255)
HoodFitness_TP_2.TextSize = 16.000
HoodFitness_TP_2.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
HoodFitness_TP_2.TextStrokeTransparency = 0.900
HoodFitness_TP_2.TextWrapped = true

ESP.Name = "ESP"
ESP.Parent = Display_Misc_Frame
ESP.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
ESP.BorderColor3 = Color3.fromRGB(0, 0, 0)
ESP.Position = UDim2.new(0.298245311, 0, 0.543592751, 0)
ESP.Size = UDim2.new(0.205630973, 0, 0.278145045, 0)
ESP.Font = Enum.Font.SourceSansSemibold
ESP.Text = "Project Dolphin's ESP, AIMLOCK, CHAMS, TRACERS"
ESP.TextColor3 = Color3.fromRGB(255, 255, 255)
ESP.TextSize = 16.000
ESP.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
ESP.TextStrokeTransparency = 0.900
ESP.TextWrapped = true

Owl_Hub_Aimbot.Name = "Owl_Hub_Aimbot"
Owl_Hub_Aimbot.Parent = Display_Misc_Frame
Owl_Hub_Aimbot.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Owl_Hub_Aimbot.BorderColor3 = Color3.fromRGB(0, 0, 0)
Owl_Hub_Aimbot.Position = UDim2.new(0.527297497, 0, 0.707566381, 0)
Owl_Hub_Aimbot.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Owl_Hub_Aimbot.Font = Enum.Font.SourceSansSemibold
Owl_Hub_Aimbot.Text = "OWL HUB AIMBOT"
Owl_Hub_Aimbot.TextColor3 = Color3.fromRGB(255, 255, 255)
Owl_Hub_Aimbot.TextSize = 16.000
Owl_Hub_Aimbot.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Owl_Hub_Aimbot.TextStrokeTransparency = 0.900
Owl_Hub_Aimbot.TextWrapped = true

AFKTOGGLE.Name = "AFK(TOGGLE)"
AFKTOGGLE.Parent = Display_Misc_Frame
AFKTOGGLE.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
AFKTOGGLE.BorderColor3 = Color3.fromRGB(0, 0, 0)
AFKTOGGLE.Position = UDim2.new(0.527297497, 0, 0.0516730547, 0)
AFKTOGGLE.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
AFKTOGGLE.Font = Enum.Font.SourceSansSemibold
AFKTOGGLE.Text = "SAFE AFK(OFF)"
AFKTOGGLE.TextColor3 = Color3.fromRGB(255, 255, 255)
AFKTOGGLE.TextSize = 15.000
AFKTOGGLE.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
AFKTOGGLE.TextStrokeTransparency = 0.900
AFKTOGGLE.TextWrapped = true

Antiban.Name = "Anti-ban"
Antiban.Parent = Display_Misc_Frame
Antiban.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Antiban.BorderColor3 = Color3.fromRGB(0, 0, 0)
Antiban.Position = UDim2.new(0.298245311, 0, 0.0516730547, 0)
Antiban.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Antiban.Font = Enum.Font.SourceSansSemibold
Antiban.Text = "ANTI-BAN V3.2"
Antiban.TextColor3 = Color3.fromRGB(255, 255, 255)
Antiban.TextSize = 16.000
Antiban.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Antiban.TextStrokeTransparency = 0.900
Antiban.TextWrapped = true

Hide_Name.Name = "Hide_Name"
Hide_Name.Parent = Display_Misc_Frame
Hide_Name.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Hide_Name.BorderColor3 = Color3.fromRGB(0, 0, 0)
Hide_Name.Position = UDim2.new(0.527297497, 0, 0.215646371, 0)
Hide_Name.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
Hide_Name.Font = Enum.Font.SourceSansSemibold
Hide_Name.Text = "HIDE PLAYERLIST NAME"
Hide_Name.TextColor3 = Color3.fromRGB(255, 255, 255)
Hide_Name.TextScaled = true
Hide_Name.TextSize = 14.000
Hide_Name.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Hide_Name.TextStrokeTransparency = 0.900
Hide_Name.TextWrapped = true

ANTIafk.Name = "ANTI-afk"
ANTIafk.Parent = Display_Misc_Frame
ANTIafk.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
ANTIafk.BorderColor3 = Color3.fromRGB(0, 0, 0)
ANTIafk.Position = UDim2.new(0.298245311, 0, 0.215646371, 0)
ANTIafk.Size = UDim2.new(0.205630973, 0, 0.101785749, 0)
ANTIafk.Font = Enum.Font.SourceSansSemibold
ANTIafk.Text = "ANTI-AFK"
ANTIafk.TextColor3 = Color3.fromRGB(255, 255, 255)
ANTIafk.TextSize = 16.000
ANTIafk.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
ANTIafk.TextStrokeTransparency = 0.900
ANTIafk.TextWrapped = true

To_player.Name = "To_player"
To_player.Parent = Display_Misc_Frame
To_player.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
To_player.BorderColor3 = Color3.fromRGB(0, 0, 0)
To_player.Position = UDim2.new(0.0161177516, 0, 0.0487638041, 0)
To_player.Size = UDim2.new(0.202941641, 0, 0.104297705, 0)
To_player.Font = Enum.Font.Cartoon
To_player.Text = "TP to Player"
To_player.TextColor3 = Color3.fromRGB(255, 255, 255)
To_player.TextSize = 16.000

Username_Box.Name = "Username_Box"
Username_Box.Parent = To_player
Username_Box.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Username_Box.BorderColor3 = Color3.fromRGB(255, 255, 255)
Username_Box.Position = UDim2.new(0, 0, 1.04998207, 0)
Username_Box.Size = UDim2.new(0.999999583, 0, 0.633662164, 0)
Username_Box.Font = Enum.Font.SourceSans
Username_Box.PlaceholderColor3 = Color3.fromRGB(178, 178, 178)
Username_Box.PlaceholderText = "Username"
Username_Box.Text = ""
Username_Box.TextColor3 = Color3.fromRGB(255, 255, 255)
Username_Box.TextSize = 14.000

Kill.Name = "Kill"
Kill.Parent = Display_Misc_Frame
Kill.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Kill.BorderColor3 = Color3.fromRGB(0, 0, 0)
Kill.Position = UDim2.new(0.0151322382, 0, 0.332597584, 0)
Kill.Size = UDim2.new(0.202999994, 0, 0.104000002, 0)
Kill.Font = Enum.Font.Cartoon
Kill.Text = "Fling Player"
Kill.TextColor3 = Color3.fromRGB(255, 255, 255)
Kill.TextSize = 16.000

Username_Box_2.Name = "Username_Box"
Username_Box_2.Parent = Kill
Username_Box_2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Username_Box_2.BorderColor3 = Color3.fromRGB(255, 255, 255)
Username_Box_2.Position = UDim2.new(0, 0, 0.991778851, 0)
Username_Box_2.Size = UDim2.new(1, 0, 0.634000003, 0)
Username_Box_2.Font = Enum.Font.SourceSans
Username_Box_2.PlaceholderColor3 = Color3.fromRGB(178, 178, 178)
Username_Box_2.PlaceholderText = "Username"
Username_Box_2.Text = ""
Username_Box_2.TextColor3 = Color3.fromRGB(255, 255, 255)
Username_Box_2.TextSize = 14.000

GMOD.Name = "GMOD"
GMOD.Parent = Main_First_2
GMOD.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
GMOD.BorderColor3 = Color3.fromRGB(255, 255, 255)
GMOD.BorderSizePixel = 0
GMOD.Position = UDim2.new(0.794992805, 0, 0.01631568, 0)
GMOD.Size = UDim2.new(0.118000001, 0, 0.0909999982, 0)
GMOD.Font = Enum.Font.SourceSansBold
GMOD.Text = "G-MODS"
GMOD.TextColor3 = Color3.fromRGB(255, 255, 255)
GMOD.TextSize = 16.000
GMOD.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
GMOD.TextStrokeTransparency = 0.800
GMOD.TextWrapped = true

Display_GMOD_Frame.Name = "Display_GMOD_Frame"
Display_GMOD_Frame.Parent = Main_First_2
Display_GMOD_Frame.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
Display_GMOD_Frame.BorderColor3 = Color3.fromRGB(30, 30, 30)
Display_GMOD_Frame.BorderSizePixel = 0
Display_GMOD_Frame.LayoutOrder = 10
Display_GMOD_Frame.Position = UDim2.new(5.46497105e-08, 0, 0.117310651, 0)
Display_GMOD_Frame.Size = UDim2.new(0.999999881, 0, 0.882689536, 0)
Display_GMOD_Frame.Visible = false

Floating_Shotgun_Bullets.Name = "Floating_Shotgun_Bullets"
Floating_Shotgun_Bullets.Parent = Display_GMOD_Frame
Floating_Shotgun_Bullets.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Floating_Shotgun_Bullets.BorderColor3 = Color3.fromRGB(0, 0, 0)
Floating_Shotgun_Bullets.Position = UDim2.new(0.336252272, 0, 0.379619569, 0)
Floating_Shotgun_Bullets.Size = UDim2.new(0.270000011, 0, 0.101999998, 0)
Floating_Shotgun_Bullets.Font = Enum.Font.SourceSansSemibold
Floating_Shotgun_Bullets.Text = "Floating Shotty Bullets"
Floating_Shotgun_Bullets.TextColor3 = Color3.fromRGB(255, 255, 255)
Floating_Shotgun_Bullets.TextScaled = true
Floating_Shotgun_Bullets.TextSize = 16.000
Floating_Shotgun_Bullets.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Floating_Shotgun_Bullets.TextStrokeTransparency = 0.900
Floating_Shotgun_Bullets.TextWrapped = true

Silenced_Silencer_Shooting.Name = "Silenced_Silencer_Shooting"
Silenced_Silencer_Shooting.Parent = Display_GMOD_Frame
Silenced_Silencer_Shooting.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Silenced_Silencer_Shooting.BorderColor3 = Color3.fromRGB(0, 0, 0)
Silenced_Silencer_Shooting.Position = UDim2.new(0.0277555138, 0, 0.379619569, 0)
Silenced_Silencer_Shooting.Size = UDim2.new(0.270000011, 0, 0.101999998, 0)
Silenced_Silencer_Shooting.Font = Enum.Font.SourceSansSemibold
Silenced_Silencer_Shooting.Text = "Silenced-Silencer-Shooting"
Silenced_Silencer_Shooting.TextColor3 = Color3.fromRGB(255, 255, 255)
Silenced_Silencer_Shooting.TextScaled = true
Silenced_Silencer_Shooting.TextSize = 16.000
Silenced_Silencer_Shooting.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Silenced_Silencer_Shooting.TextStrokeTransparency = 0.900
Silenced_Silencer_Shooting.TextWrapped = true

Floating_SMG_Bullets.Name = "Floating_SMG_Bullets"
Floating_SMG_Bullets.Parent = Display_GMOD_Frame
Floating_SMG_Bullets.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Floating_SMG_Bullets.BorderColor3 = Color3.fromRGB(0, 0, 0)
Floating_SMG_Bullets.Position = UDim2.new(0.336252272, 0, 0.543592811, 0)
Floating_SMG_Bullets.Size = UDim2.new(0.270000011, 0, 0.101999998, 0)
Floating_SMG_Bullets.Font = Enum.Font.SourceSansSemibold
Floating_SMG_Bullets.Text = "Floating Sub-MG Bullets"
Floating_SMG_Bullets.TextColor3 = Color3.fromRGB(255, 255, 255)
Floating_SMG_Bullets.TextScaled = true
Floating_SMG_Bullets.TextSize = 16.000
Floating_SMG_Bullets.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Floating_SMG_Bullets.TextStrokeTransparency = 0.900
Floating_SMG_Bullets.TextWrapped = true

Silenced_Silencer_Reloading.Name = "Silenced_Silencer_Reloading"
Silenced_Silencer_Reloading.Parent = Display_GMOD_Frame
Silenced_Silencer_Reloading.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Silenced_Silencer_Reloading.BorderColor3 = Color3.fromRGB(0, 0, 0)
Silenced_Silencer_Reloading.Position = UDim2.new(0.0277555287, 0, 0.543592751, 0)
Silenced_Silencer_Reloading.Size = UDim2.new(0.270000011, 0, 0.101999998, 0)
Silenced_Silencer_Reloading.Font = Enum.Font.SourceSansSemibold
Silenced_Silencer_Reloading.Text = "Silenced-Silencer-Reloading"
Silenced_Silencer_Reloading.TextColor3 = Color3.fromRGB(255, 255, 255)
Silenced_Silencer_Reloading.TextScaled = true
Silenced_Silencer_Reloading.TextSize = 16.000
Silenced_Silencer_Reloading.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Silenced_Silencer_Reloading.TextStrokeTransparency = 0.900
Silenced_Silencer_Reloading.TextWrapped = true

RPG_Square_Rockets.Name = "RPG_Square_Rockets"
RPG_Square_Rockets.Parent = Display_GMOD_Frame
RPG_Square_Rockets.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
RPG_Square_Rockets.BorderColor3 = Color3.fromRGB(0, 0, 0)
RPG_Square_Rockets.Position = UDim2.new(0.336252272, 0, 0.707566381, 0)
RPG_Square_Rockets.Size = UDim2.new(0.270000011, 0, 0.101999998, 0)
RPG_Square_Rockets.Font = Enum.Font.SourceSansSemibold
RPG_Square_Rockets.Text = "RPG Square Rockets"
RPG_Square_Rockets.TextColor3 = Color3.fromRGB(255, 255, 255)
RPG_Square_Rockets.TextSize = 16.000
RPG_Square_Rockets.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
RPG_Square_Rockets.TextStrokeTransparency = 0.900
RPG_Square_Rockets.TextWrapped = true

Silenced_SubMG_Reloading.Name = "Silenced_SubMG_Reloading"
Silenced_SubMG_Reloading.Parent = Display_GMOD_Frame
Silenced_SubMG_Reloading.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Silenced_SubMG_Reloading.BorderColor3 = Color3.fromRGB(0, 0, 0)
Silenced_SubMG_Reloading.Position = UDim2.new(0.336252272, 0, 0.0516730547, 0)
Silenced_SubMG_Reloading.Size = UDim2.new(0.270000011, 0, 0.101999998, 0)
Silenced_SubMG_Reloading.Font = Enum.Font.SourceSansSemibold
Silenced_SubMG_Reloading.Text = "Silenced SubMG-Reloading"
Silenced_SubMG_Reloading.TextColor3 = Color3.fromRGB(255, 255, 255)
Silenced_SubMG_Reloading.TextScaled = true
Silenced_SubMG_Reloading.TextSize = 15.000
Silenced_SubMG_Reloading.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Silenced_SubMG_Reloading.TextStrokeTransparency = 0.900
Silenced_SubMG_Reloading.TextWrapped = true

Silenced_Shotgun_Shooting.Name = "Silenced_Shotgun_Shooting"
Silenced_Shotgun_Shooting.Parent = Display_GMOD_Frame
Silenced_Shotgun_Shooting.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Silenced_Shotgun_Shooting.BorderColor3 = Color3.fromRGB(0, 0, 0)
Silenced_Shotgun_Shooting.Position = UDim2.new(0.0277555138, 0, 0.0516730584, 0)
Silenced_Shotgun_Shooting.Size = UDim2.new(0.269943237, 0, 0.101785749, 0)
Silenced_Shotgun_Shooting.Font = Enum.Font.SourceSansSemibold
Silenced_Shotgun_Shooting.Text = "Silenced-Shotty-Shooting"
Silenced_Shotgun_Shooting.TextColor3 = Color3.fromRGB(255, 255, 255)
Silenced_Shotgun_Shooting.TextSize = 14.000
Silenced_Shotgun_Shooting.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Silenced_Shotgun_Shooting.TextStrokeTransparency = 0.900
Silenced_Shotgun_Shooting.TextWrapped = true

Floating_Silencer_Bullets.Name = "Floating_Silencer_Bullets"
Floating_Silencer_Bullets.Parent = Display_GMOD_Frame
Floating_Silencer_Bullets.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Floating_Silencer_Bullets.BorderColor3 = Color3.fromRGB(0, 0, 0)
Floating_Silencer_Bullets.Position = UDim2.new(0.336252272, 0, 0.215646371, 0)
Floating_Silencer_Bullets.Size = UDim2.new(0.270000011, 0, 0.101999998, 0)
Floating_Silencer_Bullets.Font = Enum.Font.SourceSansSemibold
Floating_Silencer_Bullets.Text = "Floating Silencer Bullets"
Floating_Silencer_Bullets.TextColor3 = Color3.fromRGB(255, 255, 255)
Floating_Silencer_Bullets.TextScaled = true
Floating_Silencer_Bullets.TextSize = 14.000
Floating_Silencer_Bullets.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Floating_Silencer_Bullets.TextStrokeTransparency = 0.900
Floating_Silencer_Bullets.TextWrapped = true

Silenced_Shotty_Reloading.Name = "Silenced_Shotty_Reloading"
Silenced_Shotty_Reloading.Parent = Display_GMOD_Frame
Silenced_Shotty_Reloading.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Silenced_Shotty_Reloading.BorderColor3 = Color3.fromRGB(0, 0, 0)
Silenced_Shotty_Reloading.Position = UDim2.new(0.0277555138, 0, 0.215646371, 0)
Silenced_Shotty_Reloading.Size = UDim2.new(0.270000011, 0, 0.101999998, 0)
Silenced_Shotty_Reloading.Font = Enum.Font.SourceSansSemibold
Silenced_Shotty_Reloading.Text = "Silenced-Shotty-Reloading"
Silenced_Shotty_Reloading.TextColor3 = Color3.fromRGB(255, 255, 255)
Silenced_Shotty_Reloading.TextScaled = true
Silenced_Shotty_Reloading.TextSize = 16.000
Silenced_Shotty_Reloading.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Silenced_Shotty_Reloading.TextStrokeTransparency = 0.900
Silenced_Shotty_Reloading.TextWrapped = true

Silenced_SubMG_Shooting.Name = "Silenced_SubMG_Shooting"
Silenced_SubMG_Shooting.Parent = Display_GMOD_Frame
Silenced_SubMG_Shooting.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Silenced_SubMG_Shooting.BorderColor3 = Color3.fromRGB(0, 0, 0)
Silenced_SubMG_Shooting.Position = UDim2.new(0.0258639902, 0, 0.706379771, 0)
Silenced_SubMG_Shooting.Size = UDim2.new(0.270000011, 0, 0.101999998, 0)
Silenced_SubMG_Shooting.Font = Enum.Font.SourceSansSemibold
Silenced_SubMG_Shooting.Text = "Silenced SubMG-Shooting"
Silenced_SubMG_Shooting.TextColor3 = Color3.fromRGB(255, 255, 255)
Silenced_SubMG_Shooting.TextScaled = true
Silenced_SubMG_Shooting.TextSize = 16.000
Silenced_SubMG_Shooting.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Silenced_SubMG_Shooting.TextStrokeTransparency = 0.900
Silenced_SubMG_Shooting.TextWrapped = true

PaintBallMaskBlocky.Name = "PaintBallMaskBlocky"
PaintBallMaskBlocky.Parent = Display_GMOD_Frame
PaintBallMaskBlocky.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
PaintBallMaskBlocky.BorderColor3 = Color3.fromRGB(0, 0, 0)
PaintBallMaskBlocky.Position = UDim2.new(0.0241486728, 0, 0.866179407, 0)
PaintBallMaskBlocky.Size = UDim2.new(0.270000011, 0, 0.101999998, 0)
PaintBallMaskBlocky.Font = Enum.Font.SourceSansSemibold
PaintBallMaskBlocky.Text = "Blocky Paintball Mask"
PaintBallMaskBlocky.TextColor3 = Color3.fromRGB(255, 255, 255)
PaintBallMaskBlocky.TextSize = 16.000
PaintBallMaskBlocky.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
PaintBallMaskBlocky.TextStrokeTransparency = 0.900
PaintBallMaskBlocky.TextWrapped = true

Title.Name = "Title"
Title.Parent = Display_GMOD_Frame
Title.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Title.BackgroundTransparency = 1.000
Title.BorderColor3 = Color3.fromRGB(0, 0, 0)
Title.Position = UDim2.new(0.717792809, 0, 0.0516730621, 0)
Title.Size = UDim2.new(0.261339515, 0, 0.101999991, 0)
Title.Font = Enum.Font.SourceSansSemibold
Title.Text = "Spawn-In tools"
Title.TextColor3 = Color3.fromRGB(255, 255, 255)
Title.TextScaled = true
Title.TextSize = 15.000
Title.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Title.TextStrokeTransparency = 0.900
Title.TextWrapped = true

Spawn_Shotgun.Name = "Spawn_Shotgun"
Spawn_Shotgun.Parent = Display_GMOD_Frame
Spawn_Shotgun.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Spawn_Shotgun.BorderColor3 = Color3.fromRGB(0, 0, 0)
Spawn_Shotgun.Position = UDim2.new(0.750769973, 0, 0.213161945, 0)
Spawn_Shotgun.Size = UDim2.new(0.196722478, 0, 0.0970739424, 0)
Spawn_Shotgun.Font = Enum.Font.SourceSansSemibold
Spawn_Shotgun.Text = "Shotgun"
Spawn_Shotgun.TextColor3 = Color3.fromRGB(255, 255, 255)
Spawn_Shotgun.TextScaled = true
Spawn_Shotgun.TextSize = 15.000
Spawn_Shotgun.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Spawn_Shotgun.TextStrokeTransparency = 0.900
Spawn_Shotgun.TextWrapped = true

Spawn_Revolver.Name = "Spawn_Revolver"
Spawn_Revolver.Parent = Display_GMOD_Frame
Spawn_Revolver.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Spawn_Revolver.BorderColor3 = Color3.fromRGB(0, 0, 0)
Spawn_Revolver.Position = UDim2.new(0.750769973, 0, 0.367610186, 0)
Spawn_Revolver.Size = UDim2.new(0.196999997, 0, 0.0966238976, 0)
Spawn_Revolver.Font = Enum.Font.SourceSansSemibold
Spawn_Revolver.Text = "Revolver"
Spawn_Revolver.TextColor3 = Color3.fromRGB(255, 255, 255)
Spawn_Revolver.TextScaled = true
Spawn_Revolver.TextSize = 15.000
Spawn_Revolver.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Spawn_Revolver.TextStrokeTransparency = 0.900
Spawn_Revolver.TextWrapped = true

Spawn_Armor.Name = "Spawn_Armor"
Spawn_Armor.Parent = Display_GMOD_Frame
Spawn_Armor.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Spawn_Armor.BorderColor3 = Color3.fromRGB(0, 0, 0)
Spawn_Armor.Position = UDim2.new(0.750769973, 0, 0.522058427, 0)
Spawn_Armor.Size = UDim2.new(0.196999997, 0, 0.0966238976, 0)
Spawn_Armor.Font = Enum.Font.SourceSansSemibold
Spawn_Armor.Text = "Armor"
Spawn_Armor.TextColor3 = Color3.fromRGB(255, 255, 255)
Spawn_Armor.TextScaled = true
Spawn_Armor.TextSize = 15.000
Spawn_Armor.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Spawn_Armor.TextStrokeTransparency = 0.900
Spawn_Armor.TextWrapped = true

Spawn_Silencer.Name = "Spawn_Silencer"
Spawn_Silencer.Parent = Display_GMOD_Frame
Spawn_Silencer.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Spawn_Silencer.BorderColor3 = Color3.fromRGB(0, 0, 0)
Spawn_Silencer.Position = UDim2.new(0.750769973, 0, 0.676506698, 0)
Spawn_Silencer.Size = UDim2.new(0.196999997, 0, 0.0966238976, 0)
Spawn_Silencer.Font = Enum.Font.SourceSansSemibold
Spawn_Silencer.Text = "Silencer"
Spawn_Silencer.TextColor3 = Color3.fromRGB(255, 255, 255)
Spawn_Silencer.TextScaled = true
Spawn_Silencer.TextSize = 15.000
Spawn_Silencer.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Spawn_Silencer.TextStrokeTransparency = 0.900
Spawn_Silencer.TextWrapped = true

Spawn_Bat.Name = "Spawn_Bat"
Spawn_Bat.Parent = Display_GMOD_Frame
Spawn_Bat.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Spawn_Bat.BorderColor3 = Color3.fromRGB(0, 0, 0)
Spawn_Bat.Position = UDim2.new(0.750999987, 0, 0.824999988, 0)
Spawn_Bat.Size = UDim2.new(0.196999997, 0, 0.0966238976, 0)
Spawn_Bat.Font = Enum.Font.SourceSansSemibold
Spawn_Bat.Text = "Bat"
Spawn_Bat.TextColor3 = Color3.fromRGB(255, 255, 255)
Spawn_Bat.TextScaled = true
Spawn_Bat.TextSize = 15.000
Spawn_Bat.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
Spawn_Bat.TextStrokeTransparency = 0.900
Spawn_Bat.TextWrapped = true

SETTINGS.Name = "SETTINGS"
SETTINGS.Parent = Main_First_2
SETTINGS.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
SETTINGS.BorderColor3 = Color3.fromRGB(255, 255, 255)
SETTINGS.BorderSizePixel = 0
SETTINGS.Position = UDim2.new(0.927315354, 0, 0.01631568, 0)
SETTINGS.Size = UDim2.new(0.0710468739, 0, 0.0910000056, 0)
SETTINGS.Font = Enum.Font.SourceSansBold
SETTINGS.Text = "S"
SETTINGS.TextColor3 = Color3.fromRGB(255, 255, 255)
SETTINGS.TextSize = 16.000
SETTINGS.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
SETTINGS.TextStrokeTransparency = 0.800
SETTINGS.TextWrapped = true

Display_Settings_Frame.Name = "Display_Settings_Frame"
Display_Settings_Frame.Parent = Main_First_2
Display_Settings_Frame.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
Display_Settings_Frame.BorderColor3 = Color3.fromRGB(30, 30, 30)
Display_Settings_Frame.BorderSizePixel = 0
Display_Settings_Frame.LayoutOrder = 10
Display_Settings_Frame.Position = UDim2.new(5.46497105e-08, 0, 0.117310651, 0)
Display_Settings_Frame.Size = UDim2.new(0.999999881, 0, 0.882689536, 0)
Display_Settings_Frame.Visible = false

P_Minimize.Name = "P_Minimize"
P_Minimize.Parent = Display_Settings_Frame
P_Minimize.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
P_Minimize.BorderColor3 = Color3.fromRGB(0, 0, 0)
P_Minimize.Position = UDim2.new(0.0352187417, 0, 0.0901088417, 0)
P_Minimize.Size = UDim2.new(0.392243922, 0, 0.101999991, 0)
P_Minimize.Font = Enum.Font.SourceSansSemibold
P_Minimize.Text = "TOGGLE R-Ctrl MINIMIZE"
P_Minimize.TextColor3 = Color3.fromRGB(255, 255, 255)
P_Minimize.TextSize = 16.000
P_Minimize.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
P_Minimize.TextStrokeTransparency = 0.900
P_Minimize.TextWrapped = true

BorderFrameColor.Name = "BorderFrameColor"
BorderFrameColor.Parent = Display_Settings_Frame
BorderFrameColor.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
BorderFrameColor.BackgroundTransparency = 1.000
BorderFrameColor.BorderColor3 = Color3.fromRGB(0, 0, 0)
BorderFrameColor.Position = UDim2.new(0.0352187417, 0, 0.270596445, 0)
BorderFrameColor.Size = UDim2.new(0.392243922, 0, 0.101999991, 0)
BorderFrameColor.Font = Enum.Font.SourceSansSemibold
BorderFrameColor.Text = "Border-Frame Color"
BorderFrameColor.TextColor3 = Color3.fromRGB(255, 255, 255)
BorderFrameColor.TextSize = 16.000
BorderFrameColor.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
BorderFrameColor.TextStrokeTransparency = 0.900
BorderFrameColor.TextWrapped = true

FrameColorBlack.Name = "FrameColorBlack"
FrameColorBlack.Parent = BorderFrameColor
FrameColorBlack.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
FrameColorBlack.BorderColor3 = Color3.fromRGB(0, 0, 0)
FrameColorBlack.Position = UDim2.new(1.08290255, 0, 0, 0)
FrameColorBlack.Size = UDim2.new(0.41910395, 0, 0.977950335, 0)
FrameColorBlack.Font = Enum.Font.SourceSansSemibold
FrameColorBlack.Text = "BLACK"
FrameColorBlack.TextColor3 = Color3.fromRGB(255, 255, 255)
FrameColorBlack.TextSize = 16.000
FrameColorBlack.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
FrameColorBlack.TextStrokeTransparency = 0.900
FrameColorBlack.TextWrapped = true

FrameColorBlue.Name = "FrameColorBlue"
FrameColorBlue.Parent = BorderFrameColor
FrameColorBlue.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
FrameColorBlue.BorderColor3 = Color3.fromRGB(0, 0, 0)
FrameColorBlue.Position = UDim2.new(1.58022094, 0, 0, 0)
FrameColorBlue.Size = UDim2.new(0.41910395, 0, 0.977950335, 0)
FrameColorBlue.Font = Enum.Font.SourceSansSemibold
FrameColorBlue.Text = "D-BLUE"
FrameColorBlue.TextColor3 = Color3.fromRGB(255, 255, 255)
FrameColorBlue.TextSize = 16.000
FrameColorBlue.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
FrameColorBlue.TextStrokeTransparency = 0.900
FrameColorBlue.TextWrapped = true

TopFrameColor.Name = "TopFrameColor"
TopFrameColor.Parent = Display_Settings_Frame
TopFrameColor.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
TopFrameColor.BackgroundTransparency = 1.000
TopFrameColor.BorderColor3 = Color3.fromRGB(0, 0, 0)
TopFrameColor.Position = UDim2.new(0.0170121994, 0, 0.446334362, 0)
TopFrameColor.Size = UDim2.new(0.392243922, 0, 0.101999991, 0)
TopFrameColor.Font = Enum.Font.SourceSansSemibold
TopFrameColor.Text = "Top-Frame Color "
TopFrameColor.TextColor3 = Color3.fromRGB(255, 255, 255)
TopFrameColor.TextSize = 16.000
TopFrameColor.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
TopFrameColor.TextStrokeTransparency = 0.900
TopFrameColor.TextWrapped = true

FrameColorBlack_2.Name = "FrameColorBlack"
FrameColorBlack_2.Parent = TopFrameColor
FrameColorBlack_2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
FrameColorBlack_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
FrameColorBlack_2.Position = UDim2.new(1.12931895, 0, 0, 0)
FrameColorBlack_2.Size = UDim2.new(0.41910395, 0, 0.977950335, 0)
FrameColorBlack_2.Font = Enum.Font.SourceSansSemibold
FrameColorBlack_2.Text = "BLACK"
FrameColorBlack_2.TextColor3 = Color3.fromRGB(255, 255, 255)
FrameColorBlack_2.TextSize = 16.000
FrameColorBlack_2.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
FrameColorBlack_2.TextStrokeTransparency = 0.900
FrameColorBlack_2.TextWrapped = true

FrameColorBlue_2.Name = "FrameColorBlue"
FrameColorBlue_2.Parent = TopFrameColor
FrameColorBlue_2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
FrameColorBlue_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
FrameColorBlue_2.Position = UDim2.new(1.62663734, 0, 0, 0)
FrameColorBlue_2.Size = UDim2.new(0.41910395, 0, 0.977950335, 0)
FrameColorBlue_2.Font = Enum.Font.SourceSansSemibold
FrameColorBlue_2.Text = "D-BLUE"
FrameColorBlue_2.TextColor3 = Color3.fromRGB(255, 255, 255)
FrameColorBlue_2.TextSize = 16.000
FrameColorBlue_2.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
FrameColorBlue_2.TextStrokeTransparency = 0.900
FrameColorBlue_2.TextWrapped = true

Checkforupdates.Name = "Checkforupdates"
Checkforupdates.Parent = Display_Settings_Frame
Checkforupdates.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Checkforupdates.BorderColor3 = Color3.fromRGB(0, 0, 0)
Checkforupdates.Position = UDim2.new(0.213071749, 0, 0.831057787, 0)
Checkforupdates.Size = UDim2.new(0.57009691, 0, 0.101999991, 0)
Checkforupdates.Font = Enum.Font.SourceSansSemibold
Checkforupdates.Text = "SIGN OUT / CHECK FOR UPDATES"
Checkforupdates.TextColor3 = Color3.fromRGB(255, 255, 255)
Checkforupdates.TextSize = 16.000
Checkforupdates.TextStrokeColor3 = Color3.fromRGB(230, 0, 0)
Checkforupdates.TextStrokeTransparency = 0.800
Checkforupdates.TextWrapped = true

Da_Hood_Title_2.Name = "Da_Hood_Title"
Da_Hood_Title_2.Parent = Main_First_2
Da_Hood_Title_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Da_Hood_Title_2.BackgroundTransparency = 1.000
Da_Hood_Title_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
Da_Hood_Title_2.Position = UDim2.new(0.0156932101, 0, 0.0251518488, 0)
Da_Hood_Title_2.Size = UDim2.new(0.249955416, 0, 0.0715934187, 0)
Da_Hood_Title_2.Font = Enum.Font.SourceSansBold
Da_Hood_Title_2.Text = "HoodShark | UI  V3"
Da_Hood_Title_2.TextColor3 = Color3.fromRGB(177, 177, 177)
Da_Hood_Title_2.TextScaled = true
Da_Hood_Title_2.TextSize = 14.000
Da_Hood_Title_2.TextWrapped = true

-- Scripts:

local function SKQKD_fake_script() -- Da_HoodGUI.Draggable 
	local script = Instance.new('LocalScript', Da_HoodGUI)

	frame2 = script.Parent.Main_First
	frame2.Draggable = true
	frame2.Active = true
	frame2.Selectable = true
end
coroutine.wrap(SKQKD_fake_script)()
local function VTJHL_fake_script() -- Exit.Destroy 
	local script = Instance.new('LocalScript', Exit)

	script.Parent.MouseButton1Click:Connect(function(Close)
		local Target = script.Parent.Parent.Parent.Parent
		wait()
		Target:Destroy()
		
	end)
end
coroutine.wrap(VTJHL_fake_script)()
local function WKNPV_fake_script() -- Main_Scripts.Scripts 
	local script = Instance.new('LocalScript', Main_Scripts)

	script.Parent.MouseButton1Click:Connect(function(WaypointsOpen)
		local Target = script.Parent.Parent.Display_Main_Frame
		wait()
		if Target.Visible == true then
			Target.Visible = false
		
		elseif Target.Visible == false then
			Target.Visible = true
			script.Parent.Parent.Display_Global_Frame.Visible = false
			script.Parent.Parent.Display_Misc_Frame.Visible = false
			script.Parent.Parent.Display_GMOD_Frame.Visible = false
			script.Parent.Parent.Display_Settings_Frame.Visible = false
		end	
	end)
end
coroutine.wrap(WKNPV_fake_script)()
local function LNEIWO_fake_script() -- Misc.World 
	local script = Instance.new('LocalScript', Misc)

	script.Parent.MouseButton1Click:Connect(function(WaypointsOpen)
		local Target = script.Parent.Parent.Display_Misc_Frame
		wait()
		if Target.Visible == true then
			Target.Visible = false
		
		elseif Target.Visible == false then
			Target.Visible = true
			script.Parent.Parent.Display_Main_Frame.Visible = false
			script.Parent.Parent.Display_Global_Frame.Visible = false
			script.Parent.Parent.Display_GMOD_Frame.Visible = false
			script.Parent.Parent.Display_Settings_Frame.Visible = false
		end	
	end)
end
coroutine.wrap(LNEIWO_fake_script)()
local function WPEBFPJ_fake_script() -- Speed2.WS2 
	local script = Instance.new('LocalScript', Speed2)

	plr = game:GetService('Players').LocalPlayer
	
	script.Parent.CheckBox1.MouseButton1Click:Connect(function(Speed2)
	repeat wait() until plr.Character:FindFirstChild('Humanoid') or plr.Character:FindFirstChild('xxx')
		hum = plr.Character:FindFirstChild('Humanoid')
		if hum.Health > 0 then
			script.Parent.CheckBox2.Visible = true
			script.Parent.CheckBox1.Visible = false
			while wait() do
				if plr.Character:FindFirstChild('Humanoid') then
					hum.Name = "xxx"
					hum.WalkSpeed = 140
				if script.Parent.CheckBox1.Visible == true and hum.Health > 0 then
					hum.WalkSpeed = 16
					hum.Name = "Humanoid"
						break
					end
				end
			end
		end
	end)
	script.Parent.CheckBox2.MouseButton1Click:Connect(function(Speed2)
	repeat wait() until plr.Character:FindFirstChild('Humanoid') or plr.Character:FindFirstChild('xxx')
		local hum2 = plr.Character:FindFirstChild('xxx')
		if hum2.Health > 0 then
			script.Parent.CheckBox1.Visible = true
			script.Parent.CheckBox2.Visible = false
			hum2.WalkSpeed = 16
			hum2.Name = 'Humanoid'
			wait(1)
			hum.WalkSpeed = 16
			hum.Name = 'Humanoid'
		end
	end)
end
coroutine.wrap(WPEBFPJ_fake_script)()
local function UBNCGG_fake_script() -- Quick_Drop.Cash_Drop 
	local script = Instance.new('LocalScript', Quick_Drop)

	plr = game:GetService('Players').LocalPlayer
	
	script.Parent.CheckBox1.MouseButton1Click:Connect(function(Speed2)
	repeat wait() until plr.Character:FindFirstChild('Humanoid') or plr.Character:FindFirstChild('xxx')
		hum = plr.Character:FindFirstChild('Humanoid')
			script.Parent.CheckBox2.Visible = true
			script.Parent.CheckBox1.Visible = false
			while wait() do
				if plr.Character:FindFirstChild('Humanoid') or plr.Character:FindFirstChild('xxx') then
					wait(.1)
					if plr.DataFolder.Currency.Value >= 9800 then 
						local AMT = 9800
						game.ReplicatedStorage.MainEvent:FireServer("DropMoney",AMT)
					elseif plr.DataFolder.Currency.Value <= 100 then 
						wait()
					else 
						local AMT = plr.DataFolder.Currency.Value
					game.ReplicatedStorage.MainEvent:FireServer("DropMoney",AMT)
						end
				if script.Parent.CheckBox1.Visible == true and hum.Health > 0 then
					break
				end
			end
		end
	end)
	script.Parent.CheckBox2.MouseButton1Click:Connect(function(Speed2)
			script.Parent.CheckBox1.Visible = true
			script.Parent.CheckBox2.Visible = false
	end)
end
coroutine.wrap(UBNCGG_fake_script)()
local function XKZGCW_fake_script() -- Auto_Stomp.Auto_Stomp 
	local script = Instance.new('LocalScript', Auto_Stomp)

	plr = game:GetService('Players').LocalPlayer
	
	script.Parent.CheckBox1.MouseButton1Click:Connect(function(Speed2)
	repeat wait() until plr.Character:FindFirstChild('Humanoid') or plr.Character:FindFirstChild('xxx')
		hum = plr.Character:FindFirstChild('Humanoid')
			script.Parent.CheckBox2.Visible = true
			script.Parent.CheckBox1.Visible = false
			while wait() do
				if plr.Character:FindFirstChild('Humanoid') or plr.Character:FindFirstChild('xxx') then
					wait(.1)
							print('Stomped')
							game.ReplicatedStorage.MainEvent:FireServer("Stomp")
						end
				if script.Parent.CheckBox1.Visible == true and hum.Health > 0 then
				break
			end
		end
	end)
	script.Parent.CheckBox2.MouseButton1Click:Connect(function(Speed2)
			script.Parent.CheckBox1.Visible = true
			script.Parent.CheckBox2.Visible = false
	end)
end
coroutine.wrap(XKZGCW_fake_script)()
local function HUYZMI_fake_script() -- Display_Main_Frame.Scripts_1_Control 
	local script = Instance.new('LocalScript', Display_Main_Frame)

	plr = game:GetService('Players').LocalPlayer
	mouse = plr:GetMouse()
	script.Parent.Fly1.MouseButton1Click:Connect(function()
		localplayer = plr
			
			if workspace:FindFirstChild("Core") then
				workspace.Core:Destroy()
			end
			
			local Core = Instance.new("Part")
			Core.Name = "Core"
			Core.Size = Vector3.new(0.05, 0.05, 0.05)
	
			spawn(function()
				Core.Parent = workspace
				local Weld = Instance.new("Weld", Core)
				Weld.Part0 = Core
				Weld.Part1 = localplayer.Character.LowerTorso
				Weld.C0 = CFrame.new(0, 0, 0)
			end)
			
			workspace:WaitForChild("Core")
			
			local torso = workspace.Core
			flying = true
			local speed=10
			local keys={a=false,d=false,w=false,s=false} 
			local e1
			local e2
			local function start()
				local pos = Instance.new("BodyPosition",torso)
				local gyro = Instance.new("BodyGyro",torso)
				pos.Name="EPIXPOS"
				pos.maxForce = Vector3.new(math.huge, math.huge, math.huge)
				pos.position = torso.Position
				gyro.maxTorque = Vector3.new(9e9, 9e9, 9e9) 
				gyro.cframe = torso.CFrame
				repeat
					wait()
					localplayer.Character.Humanoid.PlatformStand=true
					local new=gyro.cframe - gyro.cframe.p + pos.position
					if not keys.w and not keys.s and not keys.a and not keys.d then
						speed=5
					end
					if keys.w then 
						new = new + workspace.CurrentCamera.CoordinateFrame.lookVector * speed
						speed=speed+0
					end
					if keys.s then 
						new = new - workspace.CurrentCamera.CoordinateFrame.lookVector * speed
						speed=speed+0
					end
					if keys.d then 
						new = new * CFrame.new(speed,0,0)
						speed=speed+0
					end
					if keys.a then 
						new = new * CFrame.new(-speed,0,0)
						speed=speed+0
					end
					if speed>10 then
						speed=5
					end
					pos.position=new.p
					if keys.w then
						gyro.cframe = workspace.CurrentCamera.CoordinateFrame*CFrame.Angles(-math.rad(speed*0),0,0)
					elseif keys.s then
						gyro.cframe = workspace.CurrentCamera.CoordinateFrame*CFrame.Angles(math.rad(speed*0),0,0)
					else
						gyro.cframe = workspace.CurrentCamera.CoordinateFrame
					end
				until flying == false
				if gyro then gyro:Destroy() end
				if pos then pos:Destroy() end
				flying=false
				localplayer.Character.Humanoid.PlatformStand=false
				speed=10
			end
			e1=mouse.KeyDown:connect(function(key)
				if not torso or not torso.Parent then flying=false e1:disconnect() e2:disconnect() return end
				if key=="w" then
					keys.w=true
				elseif key=="s" then
					keys.s=true
				elseif key=="a" then
					keys.a=true
				elseif key=="d" then
					keys.d=true
				elseif key=="x" then
					if flying==true then
						flying=false
					else
						flying=true
						start()
					end
				end
			end)
			e2=mouse.KeyUp:connect(function(key)
				if key=="w" then
					keys.w=false
				elseif key=="s" then
					keys.s=false
				elseif key=="a" then
					keys.a=false
				elseif key=="d" then
					keys.d=false
				end
			end)
			start()
	end)
	script.Parent.Noclip.MouseButton1Click:Connect(function(NOCLIP)
	
	noclip = false
	game:GetService('RunService').Stepped:connect(function()
	if noclip then
	if plr.Character:FindFirstChild('Humanoid') then
		game.Players.LocalPlayer.Character.Humanoid:ChangeState(11)
	else
		game.Players.LocalPlayer.Character.xxx:ChangeState(11)
	end
	end
	end)
	mouse.KeyDown:connect(function(key)
	
	if key == "c" then
	noclip = not noclip
	if plr.Character:FindFirstChild('Humanoid') then
		game.Players.LocalPlayer.Character.Humanoid:ChangeState(11)
	else
		game.Players.LocalPlayer.Character.xxx:ChangeState(11)
	end
	end
	end)
	end)
	
	script.Parent.Inf_Jump.MouseButton1Click:Connect(function(JUMP)
	Player = game:GetService'Players'.LocalPlayer;
	UIS = game:GetService'UserInputService';
	
	_G.JumpHeight = 50;
	
	function Action(Object, Function) if Object ~= nil then Function(Object); end end
	
	UIS.InputBegan:connect(function(UserInput)
	    if UserInput.UserInputType == Enum.UserInputType.Keyboard and UserInput.KeyCode == Enum.KeyCode.Space then
	        Action(Player.Character.Humanoid, function(self)
	            if self:GetState() == Enum.HumanoidStateType.Jumping or self:GetState() == Enum.HumanoidStateType.Freefall then
	                Action(self.Parent.HumanoidRootPart, function(self)
	                    self.Velocity = Vector3.new(0, _G.JumpHeight, 0);
	              		end)
	           		end
	        	end)
	   		 end
		end)
	end)
	
	script.Parent.God_Mode.MouseButton1Click:Connect(function(GOD)
				plr.Character.BodyEffects:FindFirstChild('BreakingParts'):Destroy()
				game:GetService("Players").LocalPlayer.PlayerGui.MainScreenGui.Bar.HP.Picture.Life.Visible = true
	end)
	
	script.Parent.UnGod_Mode.MouseButton1Click:Connect(function(UNGOD)
			local X = plr.Character.HumanoidRootPart.CFrame.X
			local Y = plr.Character.HumanoidRootPart.CFrame.Y
			local Z = plr.Character.HumanoidRootPart.CFrame.Z
			plr.Character:FindFirstChild('RagdollConstraints'):Destroy()
			plr.Character.Humanoid.Health = 0
			wait(7)
			plr.Character.HumanoidRootPart.CFrame = CFrame.new(X,Y,Z)
	end)
	
	script.Parent.Invisible.MouseButton1Click:Connect(function(Invis)
		loadstring(game:HttpGet('https://pastebin.com/raw/uZeF1687'))()
	end)
	
	script.Parent.Ragdoll_Reset.MouseButton1Click:Connect(function(RESET)
		plr.Character:FindFirstChild('RagdollConstraints'):Destroy()
		plr.Character.HumanoidRootPart:Destroy()
		plr.Character.Head:Destroy()
		plr.Character.Torso:Destroy()
	end)
	
	script.Parent.WS_V1.MouseButton1Click:Connect(function(speedmethod1)
	loadstring(game:HttpGet('https://pastebin.com/raw/kHFGTSkV'))()
	end)
	
	script.Parent.Gravity.MouseButton1Click:Connect(function(Gravity)
	local jp = Vector3.new(0, 2500, 0)
	local a = Instance.new("BodyForce")
	a.Parent = plr.Character.HumanoidRootPart
	a.Force = jp
	end)
	
	script.Parent.GetTools.MouseButton1Click:Connect(function(knife_Pick)
		char = game:GetService('Players').LocalPlayer.Character
		-------------------------------------
		function GetKnife()
			wait(.1)
			char.HumanoidRootPart.CFrame = CFrame.new(-680.2, 19.75, -254.97)
			wait()
			char.HumanoidRootPart.CFrame = CFrame.new(-115.495, 19.756, -453.45)
			wait()
			char.HumanoidRootPart.CFrame = CFrame.new(-418.208, 19.25, -748.694)
			wait()
			char.HumanoidRootPart.CFrame = CFrame.new(-418.208, 19.25, -748.694)
			wait()
			char.HumanoidRootPart.CFrame = CFrame.new(33, 19.75, -184.6)
			wait()
			char.HumanoidRootPart.CFrame = CFrame.new(243.495, 62, -450.5)
			wait()
			char.HumanoidRootPart.CFrame = CFrame.new(-103.53, 19.75, -220.21)
			wait()
			char.HumanoidRootPart.CFrame = CFrame.new(-581.775, 19.7549, -485.23)
			wait()
			char.HumanoidRootPart.CFrame = CFrame.new(-399.655, 19.7552, -461.55)
			wait()
		end
	
		wait()
		local X = char.HumanoidRootPart.CFrame.X
		local Y = char.HumanoidRootPart.CFrame.Y
		local Z = char.HumanoidRootPart.CFrame.Z
		GetKnife()
		repeat GetKnife() until plr.Backpack:FindFirstChild('[Knife]') and plr.Backpack:FindFirstChild('[LockPicker]')
		char.HumanoidRootPart.CFrame = CFrame.new(X,Y+5,Z)
	end)
	
	script.Parent.Anti_Stomp.MouseButton1Click:Connect(function(Anti_Stomp)
		while wait(.5) do
			char = game:GetService('Players').LocalPlayer.Character
			if char.Humanoid.Health < 2 then
				wait()
				char:FindFirstChild('RagdollConstraints'):Destroy()
				char:FindFirstChild('BodyEffects').SpecialParts:Destroy()
				char:FindFirstChild('Health').SpecialParts:Destroy()
				char:FindFirstChild('Animate').SpecialParts:Destroy()
				wait()
				char.HumanoidRootPart.CFrame = CFrame.new(100,3000,100)
			end
		end
	end)
	
	script.Parent.Melee_Reach.MouseButton1Click:Connect(function()
		for i,v in pairs(game:GetService'Players'.LocalPlayer.Character:GetChildren())do
	    	if v:isA("Tool") then
	           local a = Instance.new("SelectionBox",v.Handle)
	           a.Adornee = v.Handle
	           v.Handle.Size = Vector3.new(50, 50, 50)
	           --plr.Character.Humanoid:UnequipTools()
	        end
		end          
	end)
	
	script.Parent.Autorob.MouseButton1Click:Connect(function()
		loadstring(game:HttpGet('https://pastebin.com/raw/55UhgEKc'))()
	end)
	
	script.Parent.Autorob.MouseButton1Click:Connect(function()
		wait(.2)
		game.CoreGui:WaitForChild('PostmansAutoRob')
		loadstring(game:HttpGet('https://pastebin.com/raw/prV5za1A'))()
	end)
	script.Parent.Kill_Aura.MouseButton1Click:Connect(function()
		wait()
		loadstring(game:HttpGet('https://pastebin.com/raw/NPcZTdRD'))()
	end)
end
coroutine.wrap(HUYZMI_fake_script)()
local function DUEJDY_fake_script() -- ClickTP.ClickTP 
	local script = Instance.new('LocalScript', ClickTP)

	plr = game:GetService('Players').LocalPlayer
	Mouse = plr:GetMouse()
	Imput = game:GetService('UserInputService')
	Plr = plr
	Imput.InputBegan:Connect(function(input)
	  	if input.UserInputType == Enum.UserInputType.MouseButton1 and Imput:IsKeyDown(Enum.KeyCode.Tab) and script.Parent.CheckBox2.Visible == true then
	    	To(Mouse.Hit.p)
	   	end
	end)
	
	
	script.Parent.CheckBox1.MouseButton1Click:Connect(function(Speed2)
	repeat wait() until plr.Character:FindFirstChild('Humanoid') or plr.Character:FindFirstChild('xxx')
		hum = plr.Character:FindFirstChild('Humanoid')
			script.Parent.CheckBox2.Visible = true
			script.Parent.CheckBox1.Visible = false
			while wait() do
				if plr.Character:FindFirstChild('Humanoid') or plr.Character:FindFirstChild('xxx') then
					wait(.1)
						end
				if script.Parent.CheckBox1.Visible == true and hum.Health > 0 then
				break
			end
		end
	end)
	script.Parent.CheckBox2.MouseButton1Click:Connect(function(Speed2)
			script.Parent.CheckBox1.Visible = true
			script.Parent.CheckBox2.Visible = false
	end)
	
	
	
	function To(position)
	   local Chr = Plr.Character
	   if Chr ~= nil then
	       Chr:MoveTo(position)
	   end
	end
end
coroutine.wrap(DUEJDY_fake_script)()
local function OYDQS_fake_script() -- Global.Scripts 
	local script = Instance.new('LocalScript', Global)

	script.Parent.MouseButton1Click:Connect(function(WaypointsOpen)
		local Target = script.Parent.Parent.Display_Global_Frame
		wait()
		if Target.Visible == true then
			Target.Visible = false
		
		elseif Target.Visible == false then
			Target.Visible = true
			script.Parent.Parent.Display_Main_Frame.Visible = false
			script.Parent.Parent.Display_Misc_Frame.Visible = false
			script.Parent.Parent.Display_GMOD_Frame.Visible = false
			script.Parent.Parent.Display_Settings_Frame.Visible = false
		
		end	
	end)
end
coroutine.wrap(OYDQS_fake_script)()
local function YSCVBHV_fake_script() -- Display_Global_Frame.Global_Control 
	local script = Instance.new('LocalScript', Display_Global_Frame)

	plr = game:GetService('Players').LocalPlayer
	function FogSaved()
		wait()
		game:GetService('Lighting').FogEnd = 500
	end
	toggled1 = false
	script.Parent.Toggle_Fog.MouseButton1Click:Connect(function(FOG)
		if toggled1 == false then	
			wait()
			game:GetService('Lighting').FogEnd = 900000000
			toggled1 = true
		elseif toggled1 == true then
			wait()
			FogSaved()
			toggled1 = false
		end
	end)
	
	function BrightSaved()
		wait()
		game:GetService('Lighting').Brightness = 1
		game:GetService('Lighting').GlobalShadows = true
	end
	toggled2 = false
	script.Parent.Toggle_Brightness.MouseButton1Click:Connect(function(Brightness)
		if toggled2 == false then	
			wait()
			game:GetService('Lighting').Brightness = 7
			game:GetService('Lighting').GlobalShadows = false
			toggled2 = true
		elseif toggled2 == true then
			wait()
			BrightSaved()
			toggled2 = false
		end
	end)
	
	script.Parent.Chat_Logs.MouseButton1Click:Connect(function(CLOGS)
		loadstring(game:HttpGet('https://pastebin.com/raw/RstGRQD8'))()
	end)
	
	script.Parent.Anti_Pepper_Snowball.MouseButton1Click:Connect(function(PEPPER)
		wait()
		plr.PlayerGui.MainScreenGui.PepperSpray:Destroy()
		plr.PlayerGui.MainScreenGui.SNOWBALLFRAME:Destroy()
	end)
	
	script.Parent.BAT_SILENCER_TP.MouseButton1Click:Connect(function(Bat)
		game:GetService('Players').LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-82.86, 22.244, -291.56)
	end)
	
	script.Parent.AdminBase_TP.MouseButton1Click:Connect(function(Lava)
		game:GetService('Players').LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-729.895, -37.642, -885.8)
	end)
	
	script.Parent.Bank_TP.MouseButton1Click:Connect(function(Bank)
		game:GetService('Players').LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-485.668, 23.631, -285.169)
	end)
	
	script.Parent.Boxing_TP.MouseButton1Click:Connect(function(Boxing)
		game:GetService('Players').LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-236.006, 23.151, -1120.531)
	end)
	
	script.Parent.HoodFitness_TP.MouseButton1Click:Connect(function(Fitness)
		game:GetService('Players').LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-75.795, 23.701, -633.72)
	end)
	
	script.Parent.Gunshop_1TP.MouseButton1Click:Connect(function(Guns)
		game:GetService('Players').LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-582, 7.172, -739.015)
	end)
	
	script.Parent.UFO_TP.MouseButton1Click:Connect(function(UFO)
		game:GetService('Players').LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(71.565, 142.926, -690.33)
	end)
	
	script.Parent.Prison_TP.MouseButton1Click:Connect(function(Prison)
		game:GetService('Players').LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-294.162, 22.644, -111.716)
	end)
	
	script.Parent.PhoneShop_TP.MouseButton1Click:Connect(function(Phones)
		game:GetService('Players').LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-120.121, 22.946, -870.425)
	end)
	
	script.Parent.Gunshop2_TP.MouseButton1Click:Connect(function(Mask)
		game:GetService('Players').LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-210.255, 21.674, -823.16)
	end)
	
	script.Parent.SEWER_TP.MouseButton1Click:Connect(function(Sewer)
		game:GetService('Players').LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(112.622, -26.212, -277.321)
	end)
	
	script.Parent.Super_Zoom.MouseButton1Click:Connect(function()
	plr.CameraMaxZoomDistance = 99999999999
	plr.CameraMinZoomDistance = 0
	end)
	
	
end
coroutine.wrap(YSCVBHV_fake_script)()
local function DLQALB_fake_script() -- Save_Pos.Save_Pos 
	local script = Instance.new('LocalScript', Save_Pos)

	plr = game:GetService('Players').LocalPlayer
	script.Parent.Parent.Save_Pos.MouseButton1Click:Connect(function()
		X1 = plr.Character:FindFirstChild('HumanoidRootPart').CFrame.X
		Y1 = plr.Character:FindFirstChild('HumanoidRootPart').CFrame.Y
		Z1 = plr.Character:FindFirstChild('HumanoidRootPart').CFrame.Z
	end)
	script.Parent.Parent.Load_Pos.MouseButton1Click:Connect(function()
		plr.Character.HumanoidRootPart.CFrame = CFrame.new(X1,Y1+5,Z1)
	end)
end
coroutine.wrap(DLQALB_fake_script)()
local function LLRG_fake_script() -- AFKTOGGLE.AFK 
	local script = Instance.new('LocalScript', AFKTOGGLE)

	toggled = false
	script.Parent.MouseButton1Click:Connect(function()
		function ON()
			wait()
			script.Parent.Text = 'SAFE AFK(ON)'
			toggled = true
		end		
		function OFF()
			wait()
			script.Parent.Text = 'SAFE AFK(OFF)'
			toggled = false
			
		end
		
		if toggled == false then 
			ON()
			game:GetService('Players').LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-157.329, -78.224, 140.215)
			wait()
			game:GetService('Players').LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-157.329, -78.224, 140.215)
		elseif toggled == true then 
			OFF()
			game:GetService('Players').LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-485.668, 23.631, -285.169)
			wait()
			game:GetService('Players').LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-485.668, 23.631, -285.169)
		end
	end)
end
coroutine.wrap(LLRG_fake_script)()
local function SSOWJC_fake_script() -- Display_Misc_Frame.Misc_Control 
	local script = Instance.new('LocalScript', Display_Misc_Frame)

	plr = game:GetService('Players').LocalPlayer
	mouse = plr:GetMouse()
	script.Parent["Anti-ban"].MouseButton1Click:Connect(function(NOBAN)
		game.StarterGui:SetCore("SendNotification", {
	                Title = "Anti-Ban";
	                Text = "Enabled safety protocols";
	                 Duration = 20;
		                  })
	
		Players = game:GetService("Players")
		for _, player in pairs(Players:GetPlayers()) do
	    -- this code will run for all players
			if player.UserId == 163721789 or player.UserId == 15427717 or player.UserId == 8195210 or player.UserId == 28357488 or player.UserId == 17260230 or player.UserId == 201454243 or player.UserId == 179520654 or player.UserId == 201454243 or player.UserId == 16138978 or player.UserId == 228298316 or player.UserId == 32260059 or player.UserId == 9125623 or player.UserId == 11319153 or player.UserId == 34758833 or player.UserId == 16917269 or player.UserId == 89473551 or player.UserId == 63794379 or player.UserId == 93101606 then  
				wait(1)
				local plr = game:GetService('Players').LocalPlayer
				plr:Kick('KICKED TO AVOID ADMIN-BAN (Admin in server) =)')
	
			else
				print('Safe')
		end
	end
		
		
	    local AdminList = {
	    163721789, -- JokeTheFool  
	    15427717,  -- Sherosama      
	    8195210,   -- Benoxa
	    822999,    -- AStrongMuscle  
	    28357488,  -- UziGarage    
	    17260230,  -- NikoSenpai 
	    201454243, -- Papa_Mbaye 
		179520654, -- tuhklia 
		16138978,  -- zakblak20
		228298316, -- theregend27
		32260059,  -- DarkWhirlwind
		9125623,   -- coreten
		11319153,  -- LegacyCross
		34758833,  -- NatsuDBlaze
		16917269,  -- clubstar54
		89473551,  -- CheemsBurgar
		63794379,  -- iRenn
		93101606,  -- iumu
		
	    
	}
	
	game.Players.PlayerAdded:Connect(function(player)
	    for i, v in pairs(AdminList) do
	        if player.UserId == v then
	            game.StarterGui:SetCore("SendNotification", {
	                Title = "Anti-Ban";
	                Text = "An admin has joined.. kicking!";
	                 Duration = 20;
	                 })
	             wait(2)
				plr:Kick('KICKED TO AVOID ADMIN-BAN (Admin joined) =)')
	
	        end
	    end
	end)
	end)
	
	script.Parent["ANTI-afk"].MouseButton1Click:Connect(function(ANTIAFK)
		local vu = game:GetService("VirtualUser")
	game:GetService("Players").LocalPlayer.Idled:connect(function()
	   vu:Button2Down(Vector2.new(0,0),workspace.CurrentCamera.CFrame)
	   wait(1)
	   vu:Button2Up(Vector2.new(0,0),workspace.CurrentCamera.CFrame)
	end)
	            game.StarterGui:SetCore("SendNotification", {
	                Title = "Anti - AFK";
	                Text = "Enabled (No timeout)";
	                 Duration = 20;
			                  })
	end)
	
	script.Parent.Unjail.MouseButton1Click:Connect(function(UNJAIL)
		if plr.DataFolder.Currency.Value >= 125 then
			plr.Character.HumanoidRootPart.CFrame = CFrame.new(-270.94, 20.327, -242.38)--Key
			plr.Character.HumanoidRootPart.CFrame = CFrame.new(-270.94, 20.327, -242.38)--Key(Backup)
			wait()
			fireclickdetector(game:GetService("Workspace").Ignored.Shop["[Key] - $125"].ClickDetector)
			wait(.1)
			fireclickdetector(game:GetService("Workspace").Ignored.Shop["[Key] - $125"].ClickDetector)
			fireclickdetector(game:GetService("Workspace").Ignored.Shop["[Key] - $125"].ClickDetector)
			repeat wait() until plr.Backpack:FindFirstChild('[Key]')
			local Hum = plr.Character:FindFirstChildOfClass('Humanoid')
			if Hum.Health > 0 then
				key1 = plr.Backpack:FindFirstChild('[Key]')
				if key1 then
					Hum:EquipTool(key1)
					for i,v in pairs(game:GetService'Players'.LocalPlayer.Character:GetChildren())do
						if v:isA("Tool") then
								plr.Character.Humanoid:EquipTool(key1)
								plr.Character.HumanoidRootPart.CFrame = CFrame.new(-485.668, 23.631, -285.169)--Bank
								v:Activate()
			elseif plr.DataFolder.Currency.Value < 125 then
				print('Not Enough Cash (Requied 125$)')	
				wait(1)
						end
					end
				end
			end
		end
	end)
	
	script.Parent.ESP.MouseButton1Click:Connect(function(AIMBOT)
		loadstring(game:HttpGet("https://pastebin.com/raw/uw2P2fbY", true))()
	end)
	
	script.Parent.Hide_Name.MouseButton1Click:Connect(function(Remove)
		plr.leaderstats:Destroy()
		plr.DataFolder.Officer:Destroy()
	end)
	
	script.Parent.Tools_While_Cuffed.MouseButton1Click:Connect(function(Remove)
		plr.Character.BodyEffects.Cuff.Value = false
		plr.Character.BodyEffects.Cuff:Destroy()
	end)
	
	script.Parent.Rejoin.MouseButton1Click:Connect(function(Swap)
		TeleportService = game:GetService("TeleportService")
		placeID_1 = 2788229376  --Da hood
		wait()
		TeleportService:Teleport(placeID_1, plr)
	end)
	
	script.Parent.Owl_Hub_Aimbot.MouseButton1Click:Connect(function()
	loadstring(game:HttpGet("https://raw.githubusercontent.com/CriShoux/OwlHub/master/OwlHub.txt"))();
	end)
end
coroutine.wrap(SSOWJC_fake_script)()
local function RBPD_fake_script() -- To_player.ToPlayer() 
	local script = Instance.new('LocalScript', To_player)

	script.Parent.MouseButton1Click:Connect(function()
		local plr = game:GetService('Players').LocalPlayer
		local Username = script.Parent.Username_Box.Text
		local plr2 = game.Players:FindFirstChild(Username)
		-----------------------------------------------------
		plr.Character.HumanoidRootPart.CFrame = plr2.Character.HumanoidRootPart.CFrame * CFrame.new(0,4,0)
		
		
	end)
end
coroutine.wrap(RBPD_fake_script)()
local function RTUZX_fake_script() -- Kill.Kill_Player 
	local script = Instance.new('LocalScript', Kill)

	script.Parent.MouseButton1Click:Connect(function(Kill)
	
	local targetname = script.Parent.Username_Box.Text
	
	local LocalPlayer = game:GetService("Players").LocalPlayer
	local target = game:GetService("Players")[targetname]
	local torsoname = "Torso"
	if LocalPlayer.Character:FindFirstChild("Humanoid").RigType == Enum.HumanoidRigType.R15 then
	    torsoname = "UpperTorso"
	end
	if target.Character ~= nil then
	    local savepos = LocalPlayer.Character:FindFirstChild("HumanoidRootPart").CFrame
	    LocalPlayer.Character:FindFirstChild(torsoname).Anchored = true
	    local tool = Instance.new("Tool", LocalPlayer.Backpack)
	    local hat = LocalPlayer.Character:FindFirstChildOfClass("Accessory")
	    local hathandle = hat.Handle
	    hathandle.Parent = tool
	    hathandle.Massless = true
	    tool.GripPos = Vector3.new(0, 9e99, 0)
	    tool.Parent = LocalPlayer.Character
	    repeat wait() until LocalPlayer.Character:FindFirstChildOfClass("Tool") ~= nil
	    tool.Grip = CFrame.new(Vector3.new(0, 0, 0))
	    LocalPlayer.Character:FindFirstChild(torsoname).Anchored = false
	    repeat
	        LocalPlayer.Character:FindFirstChild("HumanoidRootPart").CFrame = target.Character:FindFirstChild("HumanoidRootPart").CFrame
	        wait()
	    until target.Character == nil or target.Character:FindFirstChild("Humanoid").Health <= 0 or LocalPlayer.Character == nil or LocalPlayer.Character:FindFirstChild("Humanoid").Health <= 0 or (target.Character:FindFirstChild("HumanoidRootPart").Velocity.magnitude - target.Character:FindFirstChild("Humanoid").WalkSpeed) > (target.Character:FindFirstChild("Humanoid").WalkSpeed + 20)
	    LocalPlayer.Character:FindFirstChild("Humanoid"):UnequipTools()
	    hathandle.Parent = hat
	    hathandle.Massless = false
	    tool:Destroy()
	    LocalPlayer.Character:FindFirstChild("HumanoidRootPart").CFrame = savepos
	end
	end)
end
coroutine.wrap(RTUZX_fake_script)()
local function SZKLHU_fake_script() -- GMOD.Scripts 
	local script = Instance.new('LocalScript', GMOD)

	script.Parent.MouseButton1Click:Connect(function(WaypointsOpen)
		local Target = script.Parent.Parent.Display_GMOD_Frame
		wait()
		if Target.Visible == true then
			Target.Visible = false
		
		elseif Target.Visible == false then
			Target.Visible = true
			script.Parent.Parent.Display_Main_Frame.Visible = false
			script.Parent.Parent.Display_Misc_Frame.Visible = false
			script.Parent.Parent.Display_Global_Frame.Visible = false
			script.Parent.Parent.Display_Settings_Frame.Visible = false
		end	
	end)
end
coroutine.wrap(SZKLHU_fake_script)()
local function FRYX_fake_script() -- Display_GMOD_Frame.GMOD_Control 
	local script = Instance.new('LocalScript', Display_GMOD_Frame)

	plr = game:GetService('Players').LocalPlayer
	
	script.Parent.Silenced_Shotgun_Shooting.MouseButton1Click:Connect(function(SHOTGUNSILENCEDSHOOT)
		wait()
		repeat wait() until plr.Character:FindFirstChild('[Shotgun]')
		local Shotgun = plr.Character:FindFirstChild('[Shotgun]')
		Shotgun.Handle.ShootSound.Volume = 0
		Shotgun.Handle.ShootSound.Volume = 0
	end)
	
	script.Parent.Silenced_Shotty_Reloading.MouseButton1Click:Connect(function(SHOTGUNSILENCEDRELOAD)
		wait()
		repeat wait() until plr.Character:FindFirstChild('[Shotgun]')
		local Shotgun = plr.Character:FindFirstChild('[Shotgun]')
		Shotgun.Handle.NoAmmo.Volume = 0
		Shotgun.Handle.NoAmmo.Volume = 0
	end)
	
	script.Parent.Silenced_Silencer_Shooting.MouseButton1Click:Connect(function(SILENCERSILENCEDSHOOTING)
		wait()
		repeat wait() until plr.Character:FindFirstChild('[Silencer]')
		local Silencer = plr.Character:FindFirstChild('[Silencer]')
		Silencer.Handle.ShootSound.Volume = 0
		Silencer.Handle.ShootSound.Volume = 0
	end)
	
	script.Parent.Silenced_Silencer_Reloading.MouseButton1Click:Connect(function(SILENCEDRELOADSILENCER)
		wait()
		repeat wait() until plr.Character:FindFirstChild('[Silencer]')
		local Silencer = plr.Character:FindFirstChild('[Silencer]')
		Silencer.Handle.NoAmmo.Volume = 0
		Silencer.Handle.NoAmmo.Volume = 0
	end)
	
	script.Parent.Silenced_SubMG_Shooting.MouseButton1Click:Connect(function(SMGSILENCESHOOTING)
		wait()
		repeat wait() until plr.Character:FindFirstChild('[SMG]')
		local SMG = plr.Character:FindFirstChild('[SMG]')
		SMG.Handle.ShootSound.Volume = 0
		SMG.Handle.ShootSound.Volume = 0
	end)
	
	script.Parent.Silenced_SubMG_Reloading.MouseButton1Click:Connect(function(SMGSILENCERELOAD)
		wait()
		repeat wait() until plr.Character:FindFirstChild('[SMG]')
		local SMG = plr.Character:FindFirstChild('[SMG]')
		SMG.Handle.NoAmmo.Volume = 0
		SMG.Handle.NoAmmo.Volume = 0
	end)
	
	script.Parent.Floating_Silencer_Bullets.MouseButton1Click:Connect(function(FLOATINGSILENCER)
		wait()
		repeat wait() until plr.Character:FindFirstChild('[Silencer]')
		local Silencer = plr.Character:FindFirstChild('[Silencer]')
		Silencer.Handle.ShootBBGUI:Destroy()
	end)
	
	script.Parent.Floating_Shotgun_Bullets.MouseButton1Click:Connect(function(FloatingShotgun)
		wait()
		repeat wait() until plr.Character:FindFirstChild('[Shotgun]')
		local Shotgun = plr.Character:FindFirstChild('[Shotgun]')
		Shotgun.Handle.ShootBBGUI:Destroy()
	end)
	
	script.Parent.Floating_SMG_Bullets.MouseButton1Click:Connect(function(SMGFLOATINGBULLETS)
		wait()
		repeat wait() until plr.Character:FindFirstChild('[SMG]')
		local SMG = plr.Character:FindFirstChild('[SMG]')
		SMG.Handle.ShootBBGUI:Destroy()
	end)
	
	script.Parent.RPG_Square_Rockets.MouseButton1Click:Connect(function()
		wait()
		repeat wait() until plr.Character:FindFirstChild('[RPG]')
		local RPG = plr.Character:FindFirstChild('[RPG]')
		RPG.Launcher.Mesh:Destroy()
	end)
	
	script.Parent.PaintBallMaskBlocky.MouseButton1Click:Connect(function(MASKBLOCKY)
		wait()
		repeat wait() until plr.Character:FindFirstChild('In-gameMask')
		local Mask = plr.Character:FindFirstChild('In-gameMask')
		local Target1 = Mask:FindFirstChild('Handle')
		Target1.Parent = game.Lighting
		for _, maskchildren in pairs(Mask:GetChildren()) do
		maskchildren.Head.Mesh:Destroy()
		Target1.Parent = Mask
		end
	end)
	
	script.Parent.Spawn_Armor.MouseButton1Click:Connect(function()
		local savedarmourpos = plr.Character.HumanoidRootPart.Position
		plr.Character.HumanoidRootPart.CFrame = CFrame.new(-607.871, 10.22, -786.25)
		wait(.1)
		fireclickdetector(game.Workspace.Ignored.Shop['[Medium Armor] - $1000'].ClickDetector)
		fireclickdetector(game.Workspace.Ignored.Shop['[Medium Armor] - $1000'].ClickDetector)
		plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedarmourpos)
		plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedarmourpos)
	end)
	
	script.Parent.Spawn_Shotgun.MouseButton1Click:Connect(function()
		local savedshotgunpos = plr.Character.HumanoidRootPart.Position
		plr.Character.HumanoidRootPart.CFrame = CFrame.new(-805.711, -46.24, -936.234)
		wait(.1)
		fireclickdetector(game.Workspace.Ignored.Shop['[Shotgun] - $1250'].ClickDetector)
		fireclickdetector(game.Workspace.Ignored.Shop['[Shotgun] - $1250'].ClickDetector)
		plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedshotgunpos)
		plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedshotgunpos)
	end)
	
	script.Parent.Spawn_Revolver.MouseButton1Click:Connect(function()
		local savedrevolverpos = plr.Character.HumanoidRootPart.Position
		plr.Character.HumanoidRootPart.CFrame = CFrame.new(-611.63, 19.451, -94.571)
		wait(.1)
		fireclickdetector(game.Workspace.Ignored.Shop['[Revolver] - $1300'].ClickDetector)
		fireclickdetector(game.Workspace.Ignored.Shop['[Revolver] - $1300'].ClickDetector)
		plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedrevolverpos)
		plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedrevolverpos)
	end)
	
	script.Parent.Spawn_Bat.MouseButton1Click:Connect(function()
		local savedbatpos = plr.Character.HumanoidRootPart.Position
		plr.Character.HumanoidRootPart.CFrame = CFrame.new(380.932, 44.318, -284.746)
		wait(.1)
		fireclickdetector(game.Workspace.Ignored.Shop['[Bat] - $250'].ClickDetector)
		fireclickdetector(game.Workspace.Ignored.Shop['[Bat] - $250'].ClickDetector)
		plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedbatpos)
		plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedbatpos)
	end)
	
	script.Parent.Spawn_Silencer.MouseButton1Click:Connect(function()
		local savedsilencerpos = plr.Character.HumanoidRootPart.Position
		plr.Character.HumanoidRootPart.CFrame = CFrame.new(-83.492, 19.802, -302.083)
		wait(.1)
		fireclickdetector(game.Workspace.Ignored.Shop['[Silencer] - $400'].ClickDetector)
		fireclickdetector(game.Workspace.Ignored.Shop['[Silencer] - $400'].ClickDetector)
		plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
		plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
	end)
	
end
coroutine.wrap(FRYX_fake_script)()
local function KGTK_fake_script() -- SETTINGS.Scripts 
	local script = Instance.new('LocalScript', SETTINGS)

	script.Parent.MouseButton1Click:Connect(function(WaypointsOpen)
		local Target = script.Parent.Parent.Display_Settings_Frame
		wait()
		if Target.Visible == true then
			Target.Visible = false
		
		elseif Target.Visible == false then
			Target.Visible = true
			script.Parent.Parent.Display_Main_Frame.Visible = false
			script.Parent.Parent.Display_Misc_Frame.Visible = false
			script.Parent.Parent.Display_Global_Frame.Visible = false
			script.Parent.Parent.Display_GMOD_Frame.Visible = false
		end	
	end)
end
coroutine.wrap(KGTK_fake_script)()
local function RPAS_fake_script() -- Display_Settings_Frame.Settings_Control 
	local script = Instance.new('LocalScript', Display_Settings_Frame)

	plr = game:GetService('Players').LocalPlayer
	mouse = plr:GetMouse()
	UserInputService = game:GetService("UserInputService")
	FrameObject = script.Parent.Parent.Parent.Parent.Main_First
	Open = false
	PositionClosed = UDim2.new(0.304, 0,-1, 0)
	PositionOpen = UDim2.new(0.304, 0,0.27, 0)
	target1 = script.Parent.Parent.Parent.Parent.Main_First
	
	script.Parent.P_Minimize.MouseButton1Click:Connect(function()	
		script.Parent.P_Minimize.BackgroundTransparency = 0.6
		UserInputService.InputBegan:connect(function(inputObject, gameProcessedEvent)
		    if inputObject.KeyCode == Enum.KeyCode.RightControl then
	         if Open then
	               FrameObject:TweenPosition((PositionClosed), 'Out', 'Linear',.25)
	               Open = false
	         else
	               Open = true
	               FrameObject:TweenPosition((PositionOpen), 'Out', 'Linear',.25)
				end
			end
		end)
	end)
	
	
	script.Parent.BorderFrameColor.FrameColorBlack.MouseButton1Click:Connect(function()
		script.Parent.Parent.Parent.Parent.Main_First.BorderColor3 = Color3.fromRGB(30,30,30)
	end)
	script.Parent.BorderFrameColor.FrameColorBlue.MouseButton1Click:Connect(function()
		script.Parent.Parent.Parent.Parent.Main_First.BorderColor3 = Color3.fromRGB(0, 46, 139)
	end)
	script.Parent.TopFrameColor.FrameColorBlack.MouseButton1Click:Connect(function()
		script.Parent.Parent.Parent.Top_Layer_Frame.BackgroundColor3 = Color3.fromRGB(30,30,30)
	end)
	script.Parent.TopFrameColor.FrameColorBlue.MouseButton1Click:Connect(function()
		script.Parent.Parent.Parent.Top_Layer_Frame.BackgroundColor3 = Color3.fromRGB(0, 24, 74)
	end)
	script.Parent.Checkforupdates.MouseButton1Click:Connect(function()
		wait()
		loadstring(game:HttpGet('https://pastebin.com/raw/JRAYkqQ9'))()
		repeat wait() until script.Parent.Parent.Parent.Parent:FindFirstChild('Da_HoodAccount_Info')
			wait(.3)
			local GUI = script.Parent.Parent.Parent.Parent.Da_HoodAccount_Info.Account_Info
			GUI.Visible = true
			GUI.Visible = true
		script.Parent.Parent.Parent.Parent:Destroy()
	end)
end
coroutine.wrap(RPAS_fake_script)()